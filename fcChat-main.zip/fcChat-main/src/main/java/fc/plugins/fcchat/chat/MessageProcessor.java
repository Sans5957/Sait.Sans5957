
package fc.plugins.fcchat.chat;

import fc.plugins.fcchat.manager.config.ConfigManager;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.HoverEvent;

public class MessageProcessor {
    private static final Pattern HIDDEN_TEXT_PATTERN = Pattern.compile("\\|\\|([^|]+)\\|\\|");

    public static String processHiddenText(String message, ConfigManager configManager) {
        if (!configManager.isHiddenTextEnabled()) {
            return message;
        }
        Matcher matcher = HIDDEN_TEXT_PATTERN.matcher(message);
        StringBuffer result = new StringBuffer();
        while (matcher.find()) {
            String hiddenText = matcher.group(1);
            String symbol = configManager.getHiddenTextSymbol();
            int length = configManager.getHiddenTextLength();
            String replacement = symbol.repeat(length);
            matcher.appendReplacement(result, replacement);
        }
        matcher.appendTail(result);
        return result.toString();
    }

    public static Component createHiddenTextComponent(String formattedMessage, String originalMessage, ConfigManager configManager) {
        if (!configManager.isHiddenTextEnabled()) {
            return Component.text(formattedMessage);
        }
        Matcher matcher = HIDDEN_TEXT_PATTERN.matcher(originalMessage);
        ArrayList<String> hiddenTexts = new ArrayList<String>();
        while (matcher.find()) {
            String hiddenText = matcher.group(1);
            hiddenTexts.add(hiddenText);
        }
        Component component = Component.text(formattedMessage);
        if (!hiddenTexts.isEmpty()) {
            StringBuilder hoverText = new StringBuilder();
            for (String hiddenText : hiddenTexts) {
                if (hoverText.length() > 0) {
                    hoverText.append("\n");
                }
                hoverText.append(hiddenText);
            }
            component = component.hoverEvent(HoverEvent.showText(Component.text(hoverText.toString())));
        }
        return component;
    }

    public static HoverEvent<Component> createHiddenTextHover(String originalMessage, ConfigManager configManager) {
        if (!configManager.isHiddenTextEnabled()) {
            return null;
        }
        Matcher matcher = HIDDEN_TEXT_PATTERN.matcher(originalMessage);
        ArrayList<String> hiddenTexts = new ArrayList<String>();
        while (matcher.find()) {
            String hiddenText = matcher.group(1);
            hiddenTexts.add(hiddenText);
        }
        if (!hiddenTexts.isEmpty()) {
            StringBuilder hoverText = new StringBuilder();
            for (String hiddenText : hiddenTexts) {
                if (hoverText.length() > 0) {
                    hoverText.append("\n");
                }
                hoverText.append(hiddenText);
            }
            return HoverEvent.showText(Component.text(hoverText.toString()));
        }
        return null;
    }
}
