"""Generate all 1.1 resources, including the original 1.0 assets. Python + Pillow."""
from pathlib import Path
from PIL import Image,ImageDraw
import json,random,runpy
ROOT=Path(__file__).parent
runpy.run_path(str(ROOT/'make_resources.py'))
R=ROOT/'src/main/resources';A=R/'assets/softdiaper';D=R/'data/softdiaper'
def js(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def save(im,p):p.parent.mkdir(parents=True,exist_ok=True);im.save(p)
ru={
 'item.softdiaper.laxative':'Игровое слабительное',
 'item.softdiaper.freshness_pill':'Таблетка свежести',
 'item.softdiaper.wipes':'Влажные салфетки',
 'item.softdiaper.pajamas':'Детская пижама',
 'item.softdiaper.slippers':'Мягкие тапочки',
 'item.softdiaper.pacifier':'Соска',
 'block.softdiaper.high_chair':'Детский стульчик',
 'block.softdiaper.crib':'Детская кроватка',
 'entity.softdiaper.seat':'Сиденье стульчика',
 'effect.softdiaper.laxative':'Игровое слабительное',
 'tooltip.softdiaper.fullness':'Наполнение: %s%%',
 'tooltip.softdiaper.clean':'Еда наполняет; салфетки очищают. Бумага только сушит.',
 'tooltip.softdiaper.full_slow':'Полный: скорость −25%%, мягкое падение недоступно',
 'tooltip.softdiaper.no_cushion':'Мягкое падение сейчас недоступно',
 'tooltip.softdiaper.laxative':'60 с: наполнение от еды ×2 и +5%% каждые 5 с',
 'tooltip.softdiaper.freshness':'Снимает слабительное; −40%% наполнения',
 'tooltip.softdiaper.fictional':'Вымышленный игровой эффект. Удерживайте ПКМ.',
 'tooltip.softdiaper.wipes':'ПКМ: очистить надетый памперс; −25%% влажности',
 'tooltip.softdiaper.pajamas':'Слот нагрудника. Пижама не заменяет памперс.',
 'tooltip.softdiaper.slippers':'Слот ботинок. Часть комплекта для отдыха.',
 'tooltip.softdiaper.pacifier':'Слот головы. Видна на лице персонажа.',
 'tooltip.softdiaper.cozy':'Пижама + тапочки + соска: отдых ночью лечит.',
 'message.softdiaper.full':'Памперс заполнен! Используйте салфетки или смените его.',
 'message.softdiaper.meal':'После еды: наполнение %s%%',
 'message.softdiaper.laxative':'Игровое слабительное действует 60 секунд.',
 'message.softdiaper.freshness':'Эффект снят, наполнение уменьшено.',
 'message.softdiaper.wipes':'Памперс очищен. Бумага поможет досушить.',
 'message.softdiaper.chair_occupied':'Этот стульчик уже занят.',
 'message.softdiaper.chair':'Вы сидите! Ешьте как обычно. Shift — встать.',
 'message.softdiaper.crib_dimension':'В этом измерении нельзя спать. Кроватка не взрывается.',
}
en={
 'item.softdiaper.laxative':'Fictional Laxative',
 'item.softdiaper.freshness_pill':'Freshness Pill',
 'item.softdiaper.wipes':'Wet Wipes',
 'item.softdiaper.pajamas':'Baby Pajamas',
 'item.softdiaper.slippers':'Soft Slippers',
 'item.softdiaper.pacifier':'Pacifier',
 'block.softdiaper.high_chair':'High Chair',
 'block.softdiaper.crib':'Baby Crib',
 'entity.softdiaper.seat':'High Chair Seat',
 'effect.softdiaper.laxative':'Fictional Laxative',
 'tooltip.softdiaper.fullness':'Fullness: %s%%',
 'tooltip.softdiaper.clean':'Food fills it; wipes clean it. Paper only dries it.',
 'tooltip.softdiaper.full_slow':'Full: −25%% speed; no fall cushioning',
 'tooltip.softdiaper.no_cushion':'Fall cushioning currently unavailable',
 'tooltip.softdiaper.laxative':'60 s: food fullness ×2 and +5%% every 5 s',
 'tooltip.softdiaper.freshness':'Cancels laxative; −40%% fullness',
 'tooltip.softdiaper.fictional':'Fictional game effect. Hold use to consume.',
 'tooltip.softdiaper.wipes':'Use: clean worn diaper; −25%% wetness',
 'tooltip.softdiaper.pajamas':'Chest slot. Wear together with a diaper.',
 'tooltip.softdiaper.slippers':'Feet slot. Part of the cozy outfit.',
 'tooltip.softdiaper.pacifier':'Head slot. Appears on your face.',
 'tooltip.softdiaper.cozy':'Pajamas + slippers + pacifier: rest at night to heal.',
 'message.softdiaper.full':'Diaper full! Use wipes or change it.',
 'message.softdiaper.meal':'After eating: fullness %s%%',
 'message.softdiaper.laxative':'Fictional laxative active for 60 seconds.',
 'message.softdiaper.freshness':'Effect removed; fullness reduced.',
 'message.softdiaper.wipes':'Cleaned! Paper can finish drying it.',
 'message.softdiaper.chair_occupied':'This chair is occupied.',
 'message.softdiaper.chair':'Seated! Eat as usual. Sneak to stand up.',
 'message.softdiaper.crib_dimension':'You cannot sleep here. The crib does not explode.',
}
for lang,extra in [('ru_ru',ru),('en_us',en)]:
 p=A/'lang'/f'{lang}.json';data=json.loads(p.read_text());data.update(extra);js(p,data)

# Block textures: original, deterministic 16-pixel wood/cloth palettes.
for name,base,grain in [('chair_wood',(217,190,151),(194,161,122)),('crib_wood',(236,225,205),(217,201,174)),('cushion',(132,196,211),(116,179,196)),('blanket',(172,160,214),(151,139,196))]:
 im=Image.new('RGBA',(16,16),(*base,255));d=ImageDraw.Draw(im);rng=random.Random(name)
 for i in range(28):
  x,y=rng.randrange(16),rng.randrange(16);d.line((x,y,min(15,x+rng.randrange(1,5)),y),fill=grain)
 if name in ['cushion','blanket']:
  for x,y in [(4,4),(12,11)]:
   d.line((x-1,y,x+1,y),fill='#f9ecc8');d.line((x,y-1,x,y+1),fill='#f9ecc8')
 save(im,A/'textures/block'/f'{name}.png')

# Inventory pixel art.
for name in ['laxative','freshness_pill','wipes','pajamas','slippers','pacifier']:
 im=Image.new('RGBA',(32,32));d=ImageDraw.Draw(im)
 if name in ['laxative','freshness_pill']:
  color='#ba8cdb' if name=='laxative' else '#77c7b4'
  d.polygon([(8,9),(17,4),(23,7),(27,13),(25,20),(16,27),(9,25),(5,19),(5,13)],fill='#53647d')
  d.polygon([(9,10),(17,6),(22,9),(25,14),(23,19),(16,25),(10,23),(7,18),(7,13)],fill='#f5f0e4')
  d.polygon([(9,10),(17,6),(22,9),(24,13),(15,20),(7,17),(7,13)],fill=color)
  d.line((9,12,16,8),fill='#efdef4',width=2);d.line((9,19,21,10),fill='#596b80')
 elif name=='wipes':
  d.rectangle((3,11,28,25),fill='#476f86');d.rectangle((4,12,27,24),fill='#82cbd1')
  d.rectangle((5,21,26,23),fill='#62a5b7');d.rectangle((10,13,22,19),fill='#e6f3ec')
  d.polygon([(11,15),(10,5),(16,7),(20,3),(24,7),(21,15)],fill='#526d83')
  d.polygon([(12,14),(12,7),(16,9),(20,5),(22,8),(20,14)],fill='#fffbef')
  d.rectangle((7,15,8,17),fill='#eef0c2')
 elif name=='pajamas':
  poly=[(10,5),(13,7),(18,7),(21,5),(28,10),(25,18),(22,16),(22,27),(9,27),(9,16),(6,18),(3,10)]
  d.polygon(poly,fill='#676389');d.polygon([(10,7),(13,9),(18,9),(21,7),(26,11),(24,15),(21,13),(20,25),(11,25),(10,13),(7,15),(5,11)],fill='#b5a1dc')
  d.line((16,10,16,24),fill='#8b80b6');d.rectangle((10,23,21,25),fill='#ddd2e9')
  for y in [12,17,21]:d.point((16,y),fill='#f7edc7')
  for x,y in [(12,14),(20,20)]:d.line((x-1,y,x+1,y),fill='#fff0bb');d.line((x,y-1,x,y+1),fill='#fff0bb')
 elif name=='slippers':
  for dx,dy in [(0,0),(13,3)]:
   d.polygon([(3+dx,12+dy),(7+dx,8+dy),(13+dx,10+dy),(15+dx,21+dy),(12+dx,25+dy),(3+dx,25+dy),(1+dx,22+dy)],fill='#6b648a')
   d.polygon([(4+dx,13+dy),(7+dx,10+dy),(11+dx,12+dy),(13+dx,21+dy),(11+dx,23+dy),(4+dx,23+dy),(3+dx,21+dy)],fill='#bbabdf')
   d.rectangle((5+dx,12+dy,10+dx,15+dy),fill='#776f9a');d.line((5+dx,20+dy,10+dx,20+dy),fill='#f4e7c0')
 elif name=='pacifier':
  d.ellipse((10,2,21,13),fill='#88677f');d.ellipse((12,4,19,12),fill='#e8b8cd')
  d.rounded_rectangle((3,9,28,19),radius=4,fill='#436d82');d.rounded_rectangle((5,11,26,17),radius=3,fill='#87cfda')
  d.ellipse((9,15,22,29),fill='#426b83');d.ellipse((11,17,20,27),fill='#a3e4e6');d.ellipse((13,19,18,25),fill=(0,0,0,0))
  d.rectangle((7,13,8,14),fill='#d9f2e9');d.rectangle((23,13,24,14),fill='#d9f2e9')
 save(im,A/'textures/item'/f'{name}.png');js(A/'models/item'/f'{name}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'softdiaper:item/{name}'}})

# A neutral amber fullness marker, not graphic bodily-fluid imagery.
im=Image.open(A/'textures/item/diaper_soaked.png');d=ImageDraw.Draw(im);d.rectangle((13,16,18,22),fill='#e0ae63');d.rectangle((15,15,16,20),fill='#fff1b9');d.rectangle((15,22,16,23),fill='#826545')
save(im,A/'textures/item/diaper_full.png')
js(A/'models/item/diaper_full.json',{'parent':'minecraft:item/generated','textures':{'layer0':'softdiaper:item/diaper_full'}})
p=A/'models/item/diaper.json';m=json.loads(p.read_text());m['overrides'].append({'predicate':{'softdiaper:fullness':1},'model':'softdiaper:item/diaper_full'});js(p,m)

# Clothing UVs for biped armor layer 1. Chest and arms + boot portions only.
im=Image.new('RGBA',(64,32));d=ImageDraw.Draw(im)
d.rectangle((16,16,39,31),fill='#ad9bd4');d.rectangle((40,16,55,31),fill='#ad9bd4')
d.rectangle((20,16,27,19),fill='#c7b9e2');d.rectangle((44,16,47,19),fill='#c7b9e2')
d.rectangle((16,30,39,31),fill='#ddd4e9');d.rectangle((40,29,55,31),fill='#ddd4e9')
d.line((24,20,24,29),fill='#8275aa')
for y in [21,24,27]:d.point((24,y),fill='#fff0bd')
for x,y in [(21,25),(27,22),(34,24),(46,24),(52,26)]:
 d.line((x-1,y,x+1,y),fill='#fae9ad');d.line((x,y-1,x,y+1),fill='#fae9ad')
d.rectangle((0,27,15,31),fill='#b8a7df');d.line((0,27,15,27),fill='#dfd2ee');d.line((0,31,15,31),fill='#817397')
for n in [1,2]:save(im,A/'textures/models/armor'/f'pajamas_layer_{n}.png')
im=Image.new('RGBA',(64,32));d=ImageDraw.Draw(im)
# Front face of the helmet is x8..15,y8..15; transparent elsewhere.
d.rectangle((9,11,14,12),fill='#80d0d9');d.rectangle((11,10,12,11),fill='#e3abc6')
d.line([(10,13),(10,14),(11,15),(12,15),(13,14),(13,13)],fill='#75bacd')
d.point((9,11),fill='#d5f3ed');d.point((14,11),fill='#d5f3ed')
for n in [1,2]:save(im,A/'textures/models/armor'/f'pacifier_layer_{n}.png')
status=Image.open(A/'textures/item/laxative.png').resize((18,18),Image.Resampling.NEAREST)
save(status,A/'textures/mob_effect/laxative.png')

# Block geometry. Facing NORTH is the unrotated geometry.
def box(a,b,t):return {'from':list(a),'to':list(b),'faces':{f:{'texture':'#'+t} for f in ['north','south','east','west','up','down']}}
tex={'wood':'softdiaper:block/chair_wood','cloth':'softdiaper:block/cushion','particle':'softdiaper:block/chair_wood'}
lower=[box((x,0,z),(x+3,12,z+3),'wood') for x in [1,12] for z in [1,12]]
lower+=[box((1,11,1),(15,13,15),'wood'),box((2,13,2),(14,15,14),'cloth')]
upper=[box((1,0,12),(4,13,15),'wood'),box((12,0,12),(15,13,15),'wood'),box((4,8,13),(12,13,15),'wood'),box((4,0,13),(12,8,14),'cloth'),box((0,4,0),(16,6,6),'wood'),box((0,0,4),(2,5,13),'wood'),box((14,0,4),(16,5,13),'wood')]
for part,e in [('lower',lower),('upper',upper)]:js(A/'models/block'/f'high_chair_{part}.json',{'textures':tex,'elements':e})
variants={}
for facing,y in [('north',0),('east',90),('south',180),('west',270)]:
 for half in ['lower','upper']:variants[f'facing={facing},half={half}']={'model':f'softdiaper:block/high_chair_{half}','y':y}
js(A/'blockstates/high_chair.json',{'variants':variants})
item_upper=json.loads(json.dumps(upper))
for e in item_upper:e['from'][1]+=16;e['to'][1]+=16
js(A/'models/item/high_chair.json',{'textures':tex,'elements':lower+item_upper,'display':{'gui':{'rotation':[25,225,0],'translation':[0,-2,0],'scale':[.52,.52,.52]},'ground':{'translation':[0,3,0],'scale':[.25,.25,.25]},'fixed':{'scale':[.5,.5,.5]},'thirdperson_righthand':{'rotation':[75,45,0],'scale':[.3,.3,.3]},'firstperson_righthand':{'rotation':[0,225,0],'scale':[.5,.5,.5]}}})
cribtex={'wood':'softdiaper:block/crib_wood','cloth':'softdiaper:block/blanket','pillow':'softdiaper:block/cushion','particle':'softdiaper:block/crib_wood'}
cribparts={}
for part in ['head','foot']:
 e=[box((0,3,0),(16,5,16),'wood'),box((1,5,0),(15,9,16),'cloth')]
 for x in [0,14]:
  e.append(box((x,0,1 if part=='head' else 13),(x+2,16,3 if part=='head' else 15),'wood'))
  e.append(box((x,14,0),(x+2,16,16),'wood'))
  for z in [4,8,12]:e.append(box((x,5,z),(x+1.5,14,z+1),'wood'))
 z=0 if part=='head' else 15
 e.append(box((0,14,z),(16,16,z+1),'wood'))
 for x in [4,8,12]:e.append(box((x,5,z),(x+1,14,z+1),'wood'))
 if part=='head':e.append(box((3,9,2),(13,10,7),'pillow'))
 cribparts[part]=e
 js(A/'models/block'/f'crib_{part}.json',{'textures':cribtex,'elements':e})
variants={}
for facing,y in [('north',0),('east',90),('south',180),('west',270)]:
 for part in ['head','foot']:variants[f'facing={facing},part={part}']={'model':f'softdiaper:block/crib_{part}','y':y}
js(A/'blockstates/crib.json',{'variants':variants})
head=json.loads(json.dumps(cribparts['head']))
for e in head:e['from'][2]-=16;e['to'][2]-=16
js(A/'models/item/crib.json',{'textures':cribtex,'elements':cribparts['foot']+head,'display':{'gui':{'rotation':[25,225,0],'translation':[1,0,0],'scale':[.48,.48,.48]},'ground':{'translation':[0,3,0],'scale':[.25,.25,.25]},'fixed':{'scale':[.45,.45,.45]},'thirdperson_righthand':{'rotation':[75,45,0],'scale':[.3,.3,.3]},'firstperson_righthand':{'rotation':[0,225,0],'scale':[.4,.4,.4]}}})

# Recipes; bottle and water-bucket remainders are handled by vanilla crafting.
def shapeless(name,ingredients,count=1):js(D/'recipe'/f'{name}.json',{'type':'minecraft:crafting_shapeless','category':'misc','ingredients':[{'item':'minecraft:'+i} for i in ingredients],'result':{'id':'softdiaper:'+name,'count':count}})
def shaped(name,pattern,key,count=1):js(D/'recipe'/f'{name}.json',{'type':'minecraft:crafting_shaped','category':'misc','pattern':pattern,'key':{k:({'tag':v[1:]} if v.startswith('#') else {'item':v}) for k,v in key.items()},'result':{'id':'softdiaper:'+name,'count':count}})
shapeless('laxative',['sugar','slime_ball','paper'],2)
shapeless('freshness_pill',['honey_bottle','kelp','paper'],2)
shapeless('wipes',['paper','paper','paper','water_bucket'],4)
shaped('high_chair',['SWS','PPP','S S'],{'S':'minecraft:stick','W':'minecraft:white_wool','P':'#minecraft:planks'})
shaped('crib',['F F','WWW','PPP'],{'F':'#minecraft:wooden_fences','W':'minecraft:white_wool','P':'#minecraft:planks'})
shaped('pajamas',['W W','WLW','WWW'],{'W':'minecraft:white_wool','L':'minecraft:purple_dye'})
shaped('slippers',['W W','S S'],{'W':'minecraft:white_wool','S':'minecraft:string'})
shaped('pacifier',[' S ',' P ',' N '],{'S':'minecraft:slime_ball','P':'minecraft:light_blue_dye','N':'minecraft:iron_nugget'})
for name in ['laxative','freshness_pill','wipes','high_chair','crib','pajamas','slippers','pacifier']:
 js(D/'advancement/recipes'/f'{name}.json',{'parent':'minecraft:recipes/root','criteria':{'has_material':{'trigger':'minecraft:inventory_changed','conditions':{'items':[{'items':['minecraft:white_wool','minecraft:paper','minecraft:oak_planks']}]}},'has_the_recipe':{'trigger':'minecraft:recipe_unlocked','conditions':{'recipe':'softdiaper:'+name}}},'requirements':[['has_material','has_the_recipe']],'rewards':{'recipes':['softdiaper:'+name]}})
for name,prop,val in [('high_chair','half','lower'),('crib','part','head')]:
 js(D/'loot_table/blocks'/f'{name}.json',{'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'softdiaper:'+name}],'conditions':[{'condition':'minecraft:block_state_property','block':'softdiaper:'+name,'properties':{prop:val}},{'condition':'minecraft:survives_explosion'}]}]})
for path,vals in [('block/mineable/axe',['softdiaper:high_chair','softdiaper:crib']),('block/beds',['softdiaper:crib']),('item/beds',['softdiaper:crib'])]:
 js(R/'data/minecraft/tags'/f'{path}.json',{'replace':False,'values':vals})
print('Nursery 1.1 resources generated.')
