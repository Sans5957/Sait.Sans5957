"""Rebuild original pixel-art assets and JSON resources (requires Pillow)."""
from pathlib import Path
from PIL import Image, ImageDraw
import json
R = Path(__file__).parent / 'src/main/resources'
A = R / 'assets/softdiaper'
def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

ru = {
 'item.softdiaper.diaper': 'Мягкий памперс',
 'tooltip.softdiaper.wetness': 'Влажность: %s%%',
 'tooltip.softdiaper.cushion': 'Мягкое падение: до 1,5 сердца урона',
 'tooltip.softdiaper.no_cushion': 'Слишком влажный для мягкого падения',
 'tooltip.softdiaper.paper': 'Наденьте → бумага в руке → Shift + ПКМ в воздух',
 'tooltip.softdiaper.air': 'В сухом месте: −5%% влажности каждые 5 с',
 'tooltip.softdiaper.slow': 'Промок насквозь: скорость −15%%',
 'message.softdiaper.soaked': 'Памперс промок! Shift + ПКМ с бумагой, чтобы подсушить.',
 'message.softdiaper.dry': 'Памперс высох. Мягкое приземление снова доступно!',
 'message.softdiaper.already_dry': 'Уже сухой — бумага не нужна.',
 'message.softdiaper.paper': 'Подсушено! Влажность: %s%%',
}
en = {
 'item.softdiaper.diaper': 'Soft Diaper',
 'tooltip.softdiaper.wetness': 'Wetness: %s%%',
 'tooltip.softdiaper.cushion': 'Soft landing: up to 1.5 hearts of damage',
 'tooltip.softdiaper.no_cushion': 'Too damp to cushion a fall',
 'tooltip.softdiaper.paper': 'Wear it → hold paper → sneak + use in the air',
 'tooltip.softdiaper.air': 'In a dry place: −5%% wetness every 5 s',
 'tooltip.softdiaper.slow': 'Soaked: −15%% movement speed',
 'message.softdiaper.soaked': 'Soaked! Sneak + use paper to dry your diaper.',
 'message.softdiaper.dry': 'Dry again! Soft landing is available.',
 'message.softdiaper.already_dry': 'Already dry — no paper needed.',
 'message.softdiaper.paper': 'Dried! Wetness: %s%%',
}
for lang, data in [('ru_ru',ru),('en_us',en)]: save_json(A/'lang'/f'{lang}.json',data)

save_json(R/'data/softdiaper/recipe/diaper.json', {
 'type':'minecraft:crafting_shaped','category':'equipment',
 'pattern':['S S','WPW',' P '],
 'key':{'S':{'item':'minecraft:string'}, 'W':{'item':'minecraft:white_wool'},'P':{'item':'minecraft:paper'}},
 'result':{'id':'softdiaper:diaper','count':1}
})
save_json(R/'data/softdiaper/advancement/recipes/diaper.json', {
 'parent':'minecraft:recipes/root',
 'criteria':{
   'has_wool':{'trigger':'minecraft:inventory_changed','conditions':{'items':[{'items':'minecraft:white_wool'}]}},
   'has_the_recipe':{'trigger':'minecraft:recipe_unlocked','conditions':{'recipe':'softdiaper:diaper'}}
 },
 'requirements':[['has_wool','has_the_recipe']],
 'rewards':{'recipes':['softdiaper:diaper']}
})

outline = '#537787'
for state in ['diaper','diaper_damp','diaper_soaked']:
    im=Image.new('RGBA',(32,32));d=ImageDraw.Draw(im)
    d.polygon([(3,7),(28,7),(28,15),(25,17),(24,22),(20,26),(11,26),(7,22),(6,17),(3,15)],fill=outline)
    d.polygon([(4,8),(27,8),(27,14),(24,16),(23,21),(19,25),(12,25),(8,21),(7,16),(4,14)],fill='#dce9ed')
    d.polygon([(8,11),(23,11),(23,17),(21,22),(18,24),(13,24),(10,21),(8,17)],fill='#f9fcf4')
    d.rectangle((4,8,27,10),fill='#b2d8df');d.line((5,8,26,8),fill='#e6faf7')
    d.rectangle((3,11,9,14),fill=outline);d.rectangle((4,11,8,13),fill='#72c6d2');d.line((5,11,8,11),fill='#bef1e9')
    d.rectangle((22,11,28,14),fill=outline);d.rectangle((23,11,27,13),fill='#72c6d2');d.line((24,11,27,11),fill='#bef1e9')
    d.line([(8,16),(9,20),(12,23)],fill='#9dbcc8');d.line([(23,16),(22,20),(19,23)],fill='#9dbcc8')
    # A small moisture indicator, blue rather than bodily-fluid imagery.
    indicator = {'diaper':'#c6decf','diaper_damp':'#63b6dc','diaper_soaked':'#3280c3'}[state]
    d.rectangle((15,15,16,21),fill=indicator)
    d.point((15,14),fill=indicator)
    if state != 'diaper':
        d.line((12,18,12,20),fill=indicator);d.line((19,18,19,20),fill=indicator)
    if state == 'diaper_soaked':
        d.line((10,17,10,18),fill=indicator);d.line((21,17,21,18),fill=indicator)
    im.save(A/'textures/item'/f'{state}.png')
    model={'parent':'minecraft:item/generated','textures':{'layer0':f'softdiaper:item/{state}'}}
    if state=='diaper':
        model['overrides']=[
          {'predicate':{'softdiaper:wetness':0.5},'model':'softdiaper:item/diaper_damp'},
          {'predicate':{'softdiaper:wetness':1.0},'model':'softdiaper:item/diaper_soaked'}]
    save_json(A/'models/item'/f'{state}.json',model)

# Standard 64x32 biped leggings UV. Only the waist and very top of each
# leg are opaque: this renders a padded garment, not full-length trousers.
im=Image.new('RGBA',(64,32));d=ImageDraw.Draw(im)
# Body side/front/back faces at x=16..39, y=20..31.
d.rectangle((16,28,39,31),fill='#eef5ef')
d.rectangle((16,28,39,28),fill='#77c3cf')
d.rectangle((16,29,39,29),fill='#d3edf0')
for x in [16,28]:
    d.rectangle((x,30,x+3,31),fill='#a4d9df')
d.rectangle((23,30,24,31),fill='#c6decf')
# Top cap of legs + the first four rows of their side faces.
d.rectangle((4,16,11,19),fill='#eff5ef')
d.rectangle((0,20,15,22),fill='#f7faf2')
d.rectangle((0,23,15,23),fill='#b3ced4')
d.rectangle((0,20,3,21),fill='#b8dfe3')
d.rectangle((12,21,15,22),fill='#e0ecec')
for layer in [1,2]: im.save(A/'textures/models/armor'/f'cotton_layer_{layer}.png')
icon=Image.new('RGBA',(128,128),'#122d35')
item=Image.open(A/'textures/item/diaper.png').resize((112,112),Image.Resampling.NEAREST)
icon.alpha_composite(item,(8,8));icon.save(A/'icon.png')
print('Resources generated.')
