from pathlib import Path
from PIL import Image,ImageDraw
import json,math,base64,html
R=Path(__file__).parent;A=R/'src/main/resources/assets/softdiaper'
def uri(path):return 'data:image/png;base64,'+base64.b64encode(Path(path).read_bytes()).decode()
def model_preview(name):
 m=json.loads((A/'models/item'/f'{name}.json').read_text());faces=[]
 palette={'wood':(218,193,158) if name=='high_chair' else (228,216,193),'cloth':(123,187,204) if name=='high_chair' else (166,148,211),'pillow':(128,199,211)}
 for e in m['elements']:
  x,y,z=e['from'];X,Y,Z=e['to'];t=e['faces']['up']['texture'][1:];c=palette[t]
  ff=[([(x,Y,z),(X,Y,z),(X,Y,Z),(x,Y,Z)],1.1), ([(X,y,z),(X,y,Z),(X,Y,Z),(X,Y,z)],.82), ([(x,y,z),(X,y,z),(X,Y,z),(x,Y,z)],.95)]
  for pts,shade in ff:
   depth=sum(p[0]-p[2]+p[1]*1.2 for p in pts)/4
   q=[((p[0]+p[2])*.866,(p[2]-p[0])*.5-p[1]) for p in pts]
   faces.append((depth,q,tuple(min(255,int(v*shade)) for v in c)))
 coords=[v for _,p,_ in faces for v in p];xmin=min(x for x,y in coords);xmax=max(x for x,y in coords);ymin=min(y for x,y in coords);ymax=max(y for x,y in coords)
 scale=min(108/(xmax-xmin),114/(ymax-ymin));im=Image.new('RGBA',(128,128));d=ImageDraw.Draw(im)
 for _,p,c in sorted(faces,key=lambda f:f[0]):
  q=[((x-(xmin+xmax)/2)*scale+64,(y-ymin)*scale+7) for x,y in p];d.polygon(q,fill=(*c,255),outline=tuple(max(0,int(v*.8)) for v in c))
 path=R/'guide-assets'/f'{name}.png';path.parent.mkdir(exist_ok=True);im.save(path);return path
items=[('diaper','Памперс','Еда наполняет. Вода мочит. Две отдельные шкалы.'),('laxative','Слабительное','Вымышленный эффект на 60 с: еда ×2 и наполнение со временем.'),('freshness_pill','Таблетка свежести','Снимает эффект и убирает 40% наполнения.'),('wipes','Салфетки','ПКМ: очистить надетый памперс и немного подсушить.'),('high_chair','Стульчик','ПКМ — сесть. Можно есть сидя. Shift — встать.'),('crib','Кроватка','Настоящий сон и точка возрождения. Размер 1 × 2 блока.'),('pajamas','Пижама','Сиреневый верх со звёздами в слот нагрудника.'),('slippers','Тапочки','Мягкая обувь. Слот поножей остаётся для памперса.'),('pacifier','Соска','Надевается в слот головы и видна на лице.')]
cards=''
for id,title,desc in items:
 image=model_preview(id) if id in ['high_chair','crib'] else A/'textures/item'/f'{id}.png'
 cards+=f'<article class="card"><img src="{uri(image)}" alt="{html.escape(title)}"><h3>{title}</h3><p>{desc}</p></article>'
page='''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Детская комната · Soft Diaper 1.1</title><style>
*{box-sizing:border-box}body{margin:0;background:#15252f;color:#f2edf5;font:16px/1.65 system-ui,sans-serif}main{max-width:1040px;margin:auto;padding:44px 24px}.eyebrow{font:700 12px/1.5 monospace;letter-spacing:2px;color:#b9a8de}h1{font-size:clamp(38px,7vw,66px);letter-spacing:-2px;line-height:1.06;margin:18px 0}h2{font-size:25px;margin-top:0}h3{font-size:18px;margin:10px 0 6px}p{margin:8px 0;color:#becbd3}header{padding:15px 0 30px;border-bottom:1px solid #46505d}.lead{font-size:19px;max-width:690px}.notice{background:#423846;border:1px solid #78657c;border-radius:14px;padding:18px 22px;margin:28px 0}.notice b{color:#f4d7ac}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:26px 0}.card{border:1px solid #3d4e5a;background:#21343f;border-radius:16px;padding:20px}.card img{width:88px;height:88px;image-rendering:pixelated;float:right;margin-left:7px}.card p{font-size:14px;clear:both;padding-top:7px}.columns{display:grid;grid-template-columns:1fr 1fr;gap:22px;margin:28px 0}.panel{padding:26px;border:1px solid #4b5067;border-radius:16px;background:#292f44}a{color:#a6e1d5}code{background:#11232d;color:#dbe7ed;padding:3px 6px;border-radius:4px;font-size:13px;overflow-wrap:anywhere}li{margin:9px 0}ol,ul{padding-left:22px}.small{font-size:13px;color:#9caeba}.hint{border-left:3px solid #a8d9d0;padding:12px 20px}details{margin-top:28px;padding:22px;background:#1d303b;border-radius:16px}summary{cursor:pointer;font-size:19px;color:#c8b6eb;font-weight:700}.full{white-space:pre-wrap;font:15px/1.7 system-ui,sans-serif;color:#cad6dc;word-break:break-word}footer{font-size:12px;margin-top:28px;color:#93a5b3;border-top:1px solid #46505d;padding-top:20px}@media(max-width:700px){.cards{grid-template-columns:repeat(2,1fr)}.columns{grid-template-columns:1fr}.card img{float:none}.card{padding:16px}}@media(max-width:420px){.cards{grid-template-columns:1fr}}
</style><main><header><div class="eyebrow">SOFT DIAPER 1.1.0 / MINECRAFT JAVA 1.21.1 / FABRIC</div><h1>Детская комната</h1><p class="lead">Еда и наполнение, игровые таблетки, мебель, пижама и соска — обновление мода «Мягкий памперс».</p></header>
<div class="notice"><b>Обновляете 1.0?</b> Сначала удалите старый JAR из <code>mods</code>, затем добавьте <code>soft-diaper-1.1.0.jar</code>. Две версии одновременно не устанавливайте. Сохраните резервную копию мира.</div>
<h2>Что добавлено</h2><div class="cards">'''+cards+'''</div><p class="small">Выше — превью ресурсов и моделей, не скриншоты игры. Мод не меняет размер или возраст персонажа.</p>
<div class="columns"><section class="panel"><h2>Установка</h2><ol><li>Установите <a href="https://fabricmc.net/use/installer/">Fabric Loader</a> 0.16.14+ для Minecraft 1.21.1.</li><li>Скачайте <a href="https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/0.116.6+1.21.1/fabric-api-0.116.6+1.21.1.jar">Fabric API 0.116.6+1.21.1</a>.</li><li>Положите оба JAR — мод и API — в <code>mods</code> выбранной сборки.</li><li>Запустите Fabric 1.21.1 на Java 21.</li></ol><p class="small">Windows: <code>%APPDATA%\\.minecraft\\mods</code><br>На сервере мод нужен серверу и всем игрокам. Fabric API в архив не включён.</p></section>
<section class="panel"><h2>Быстрый старт</h2><ul><li>Наденьте памперс и съешьте хлеб: <b>+20% наполнения</b>.</li><li>Салфетки + ПКМ очищают; бумага + Shift + ПКМ только сушит.</li><li>ПКМ по стульчику — сесть; <b>Shift — встать</b>.</li><li>ПКМ по кроватке — сон по обычным правилам игры.</li><li>Пижама, тапочки и соска вместе дают небольшой бонус лечения при отдыхе ночью.</li></ul></section></div>
<p class="hint">Влажность и наполнение — разные шкалы. При 100% наполнения скорость −25%, при 100% влажности −15%. Штрафы не складываются. Таблетки имеют исключительно вымышленные игровые эффекты.</p>
<h2>Найти в игре</h2><p>Творческий инвентарь → «Инструменты и приспособления», либо поиск по названию.</p><p><code>/give @s softdiaper:high_chair</code> &nbsp; <code>/give @s softdiaper:crib</code></p>
<details open><summary>Все рецепты, управление и сборка исходников</summary><div class="full">'''+html.escape((R/'README.md').read_text())+'''</div></details><footer>Оригинальные код и текстуры: MIT. Неофициальный мод, не связан с Mojang или Microsoft.</footer></main></html>'''
(R/'README.html').write_text(page,encoding='utf-8')
print('HTML guide generated.')
