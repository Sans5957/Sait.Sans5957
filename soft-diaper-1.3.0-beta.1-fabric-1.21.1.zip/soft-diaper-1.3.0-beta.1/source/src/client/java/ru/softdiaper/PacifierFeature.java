package ru.softdiaper;
import net.minecraft.client.model.*;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.util.Identifier;
import ru.softdiaper.care.CarePose;

/** Real 3D geometry attached to the animated head, not a flat inventory sprite. */
public final class PacifierFeature extends FeatureRenderer<AbstractClientPlayerEntity,PlayerEntityModel<AbstractClientPlayerEntity>> {
    private static final Identifier TEXTURE=SoftDiaperMod.id("textures/entity/pacifier_3d.png");
    private final ModelPart pacifier,cloth;
    public PacifierFeature(FeatureRendererContext<AbstractClientPlayerEntity,PlayerEntityModel<AbstractClientPlayerEntity>> context){
        super(context);ModelData data=new ModelData();
        ModelPartBuilder shield=ModelPartBuilder.create()
            .uv(0,0).cuboid(-2.6F,-2.3F,-5.0F,5.2F,2.3F,.8F)
            .uv(0,8).cuboid(-.65F,-1.9F,-5.6F,1.3F,1.2F,.65F)
            .uv(0,16).cuboid(-1.3F,-.2F,-5.3F,.4F,2.0F,.45F)
            .uv(0,16).cuboid(.9F,-.2F,-5.3F,.4F,2.0F,.45F)
            .uv(0,16).cuboid(-.9F,1.55F,-5.3F,1.8F,.4F,.45F)
            .uv(0,16).cuboid(-.9F,-.3F,-5.3F,1.8F,.4F,.45F);
        data.getRoot().addChild("pacifier",shield,ModelTransform.NONE);
        pacifier=TexturedModelData.of(data,32,32).createModel().getChild("pacifier");
        ModelData c=new ModelData();c.getRoot().addChild("cloth",ModelPartBuilder.create().uv(16,16).cuboid(-2,9,-4,5,1,5),ModelTransform.NONE);
        cloth=TexturedModelData.of(c,32,32).createModel().getChild("cloth");
    }
    @Override public void render(MatrixStack matrices,VertexConsumerProvider consumers,int light,AbstractClientPlayerEntity player,float limbAngle,float limbDistance,float tickDelta,float animationProgress,float headYaw,float headPitch){
        if(player.isInvisible())return;
        VertexConsumer vertices=consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));
        if(player.getEquippedStack(EquipmentSlot.HEAD).isOf(NurseryContent.PACIFIER)&&!CarePose.has(player,CarePose.BEING_FED)){
            matrices.push();getContextModel().head.rotate(matrices);
            pacifier.render(matrices,vertices,light,OverlayTexture.DEFAULT_UV);matrices.pop();
        }
        if(CarePose.has(player,CarePose.CHANGING)){
            matrices.push();getContextModel().rightArm.rotate(matrices);
            cloth.render(matrices,vertices,light,OverlayTexture.DEFAULT_UV);matrices.pop();
        }
    }
}
