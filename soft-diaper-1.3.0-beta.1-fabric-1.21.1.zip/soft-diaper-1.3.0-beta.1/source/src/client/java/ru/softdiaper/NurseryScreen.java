package ru.softdiaper;
import com.google.gson.*;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import ru.softdiaper.network.ActionPayload;
/** Three pages share the same server-owned target and permission checks. */
public final class NurseryScreen extends Screen {
    private JsonObject data;private String selected="";private int x,y,w,h,page;
    public NurseryScreen(JsonObject data){super(Text.translatable("gui.softdiaper.title"));this.data=data;}
    private String str(JsonObject o,String key){return o!=null&&o.has(key)?o.get(key).getAsString():"";}
    private boolean bool(JsonObject o,String key){return o!=null&&o.has(key)&&o.get(key).getAsBoolean();}
    private int number(JsonObject o,String key){return o!=null&&o.has(key)?o.get(key).getAsInt():0;}
    private String role(){return str(data,"role");}
    private JsonArray childEntries(){return data.has("children")?data.getAsJsonArray("children"):new JsonArray();}
    private JsonObject target(){
        if(role().equals("child")||role().equals("none"))return data.getAsJsonObject("self");
        for(JsonElement e:childEntries())if(str(e.getAsJsonObject(),"id").equals(selected))return e.getAsJsonObject();
        if(!childEntries().isEmpty()){JsonObject first=childEntries().get(0).getAsJsonObject();selected=str(first,"id");return first;}
        return new JsonObject();
    }
    public void update(JsonObject next){String oldRole=role(),oldOffer=str(target(),"offer");data=next;if(!oldRole.equals(role())||!oldOffer.equals(str(target(),"offer")))init();}
    private void send(String op){ClientPlayNetworking.send(new ActionPayload(op,str(target(),"id")));}
    private void button(int col,int row,String key,String op){
        int bw=(w-48)/2,by=y+h-94+row*26;
        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.softdiaper."+key),b->{if(op.equals("close"))close();else send(op);}).dimensions(x+20+col*(bw+8),by,bw,22).build());
    }
    @Override protected void init(){
        clearChildren();w=Math.min(440,width-16);h=Math.min(348,height-16);x=(width-w)/2;y=(height-h)/2;
        int tw=(w-48)/3;
        for(int i=0;i<3;i++){final int tab=i;var btn=ButtonWidget.builder(Text.translatable("gui.softdiaper.page"+i),b->{page=tab;init();}).dimensions(x+20+i*(tw+4),y+42,tw,20).build();btn.active=page!=i;addDrawableChild(btn);}
        if(role().equals("nanny"))addDrawableChild(ButtonWidget.builder(Text.translatable("gui.softdiaper.select"),b->{var list=childEntries();if(list.isEmpty())return;int at=0;for(int i=0;i<list.size();i++)if(str(list.get(i).getAsJsonObject(),"id").equals(selected))at=i;selected=str(list.get((at+1)%list.size()).getAsJsonObject(),"id");}).dimensions(x+w-116,y+69,96,18).build());
        String[][] keys;
        if(role().equals("nanny"))keys=switch(page){
            case 1->new String[][]{{"dress","dress"},{"stop","stop"},{"wash","wash"},{"play","play"},{"bed","bed"},{"close","close"}};
            case 2->new String[][]{{"wash","wash"},{"play","play"},{"bed","bed"},{"feed","feed"},{"stop","stop"},{"close","close"}};
            default->new String[][]{{"carry","carry"},{"table","table"},{"feed","feed"},{"change","change"},{"stop","stop"},{"close","close"}};
        };
        else if(role().equals("child"))keys=switch(page){
            case 1->new String[][]{{"wear_upper","wear_upper"},{"remove_upper","remove_upper"},{"wear_lower","wear_lower"},{"remove_lower","remove_lower"},{"stop","stop"},{"close","close"}};
            case 2->new String[][]{{"request_food","request_food"},{"request_bed","request_bed"},{"request_play","request_play"},{"request_wash","request_wash"},{"toy","toy"},{"close","close"}};
            default->new String[][]{{"call","call"},{"table","table"},{"sleep","sleep"},{"pause","pause"},{"stop","stop"},{"close","close"}};
        };
        else keys=new String[][]{{"remove_upper","remove_upper"},{"remove_lower","remove_lower"},{"close","close"}};
        if(role().equals("child")&&!str(target(),"offer").isEmpty()){keys[0]=new String[]{"accept","accept"};keys[1]=new String[]{"reject","reject"};}
        for(int i=0;i<keys.length;i++)button(i%2,i/2,keys[i][0],keys[i][1]);
    }
    private void label(DrawContext c,Text t,int px,int py,int color){c.drawTextWithShadow(textRenderer,t,px,py,color);}
    private void bar(DrawContext c,String key,int amount,int max,int py,int color){
        label(c,Text.translatable("gui.softdiaper."+key,amount),x+20,py,0xD9E8EE);
        int bx=x+148,bw=w-170;c.fill(bx,py-1,bx+bw,py+11,0xFF101D29);c.fill(bx,py-1,bx+Math.round(bw*Math.max(0,Math.min(max,amount))/(float)max),py+11,color);
    }
    private void slot(DrawContext c,JsonObject t,String key,int py){
        Identifier id=Identifier.tryParse(str(t,key));ItemStack stack=id==null?ItemStack.EMPTY:Registries.ITEM.get(id).getDefaultStack();
        c.fill(x+20,py,x+42,py+22,0xFF101D29);c.drawItem(stack,x+23,py+3);
        label(c,Text.translatable("gui.softdiaper.slot_"+key),x+50,py+1,0x93D8CE);
        label(c,stack.isEmpty()?Text.translatable("gui.softdiaper.empty"):stack.getName(),x+50,py+12,0xE9E9F0);
    }
    @Override public void render(DrawContext c,int mouseX,int mouseY,float delta){
        c.fill(0,0,width,height,0xAF071019);c.fill(x,y,x+w,y+h,0xF0203043);c.fill(x,y,x+w,y+36,0xFF3D4669);c.fill(x,y,x+3,y+h,0xFF93D8CE);
        label(c,Text.translatable("gui.softdiaper."+role()+"_title"),x+18,y+14,0xF5F3FF);c.drawItem(NurseryContent.PACIFIER.getDefaultStack(),x+w-34,y+10);
        JsonObject t=target();String name=str(t,"name");label(c,Text.translatable("gui.softdiaper.player",name.isEmpty()?"—":name),x+20,y+73,0xFFFFFF);
        boolean compact=h<320,tiny=h<300;String offer=str(t,"offer");
        if(!offer.isEmpty())label(c,Text.translatable("gui.softdiaper.offer",Text.translatable("extra.softdiaper."+offer)),x+20,y+91,0xF8D686);
        else if(role().equals("child"))label(c,Text.translatable("gui.softdiaper.nanny",str(data,"nanny").isEmpty()?"—":str(data,"nanny")),x+20,y+91,0xBAC7DC);
        if(!tiny){
            if(page==1){slot(c,t,"top",y+112);slot(c,t,"skirt",y+145);if(!compact)label(c,Text.translatable("gui.softdiaper.layer_hint"),x+20,y+181,0xBAC7DC);}
            else if(page==2){bar(c,"mood",number(t,"mood"),100,y+115,0xFFDFA8C0);bar(c,"clean",number(t,"clean"),100,y+139,0xFF70BBD1);}
            else {if(bool(t,"diaper")){bar(c,"wet",number(t,"wet"),100,y+112,0xFF70BBD1);bar(c,"full",number(t,"full"),100,y+135,0xFFE0B56A);}else label(c,Text.translatable("gui.softdiaper.no_diaper"),x+20,y+115,0xE8BD80);
                if(!compact){bar(c,"food",number(t,"food"),20,y+158,0xFF99C891);String state=bool(t,"paused")?"paused":bool(t,"table")?"lying":bool(t,"carried")?"carried":"ready";label(c,Text.translatable("gui.softdiaper.state",Text.translatable("gui.softdiaper.state_"+state)),x+20,y+181,0xCFC5E8);}}
            if(!compact)label(c,Text.translatable("gui.softdiaper.consent_hint"),x+20,y+202,0xAABCCB);
        }
        var lines=textRenderer.wrapLines(Text.translatable("care.softdiaper."+str(data,"notice")),w-40);int ny=y+h-120;
        for(int i=0;i<Math.min(2,lines.size());i++)c.drawTextWithShadow(textRenderer,lines.get(i),x+20,ny+i*11,0xE9DAAF);
        super.render(c,mouseX,mouseY,delta);
    }
    @Override public void close(){ClientPlayNetworking.send(new ActionPayload("close",""));super.close();}
    @Override public void renderBackground(DrawContext c,int x,int y,float d){}
    @Override public boolean shouldPause(){return false;}
}
