package ru.softdiaper.mixin;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.softdiaper.care.CarePose;
@Mixin(PlayerEntityRenderer.class)
public abstract class CareRendererMixin {
    @Inject(method="setupTransforms(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/util/math/MatrixStack;FFFF)V",at=@At("TAIL"))
    private void softdiaper$layDown(AbstractClientPlayerEntity p,MatrixStack matrices,float animationProgress,float bodyYaw,float tickDelta,float scale,CallbackInfo ci){
        if(CarePose.has(p,CarePose.ON_TABLE)){
            matrices.translate(0,.25,0);matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90));matrices.translate(0,-.9,0);
        }else if(CarePose.has(p,CarePose.CARRIED)){
            matrices.translate(0,.6,0);matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(75));matrices.scale(.75F,.75F,.75F);matrices.translate(0,-.9,0);
        }
    }
}
