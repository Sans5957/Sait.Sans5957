package ru.softdiaper;
import net.minecraft.client.render.entity.*;
import net.minecraft.util.Identifier;
public final class ChangingSeatRenderer extends EntityRenderer<ChangingSeatEntity> {
    public ChangingSeatRenderer(EntityRendererFactory.Context ctx){super(ctx);shadowRadius=0;}
    @Override public Identifier getTexture(ChangingSeatEntity entity){return SoftDiaperMod.id("textures/block/crib_wood.png");}
}
