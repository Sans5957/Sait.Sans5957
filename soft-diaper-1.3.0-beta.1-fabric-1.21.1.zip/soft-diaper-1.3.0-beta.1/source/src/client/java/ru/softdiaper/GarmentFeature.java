package ru.softdiaper;
import net.minecraft.client.model.*;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.feature.*;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import ru.softdiaper.care.WardrobeView;
/** Two cosmetic layers, not vanilla armor: diaper and its components are untouched. */
public final class GarmentFeature extends FeatureRenderer<AbstractClientPlayerEntity,PlayerEntityModel<AbstractClientPlayerEntity>> {
    private static final Identifier TEXTURE=SoftDiaperMod.id("textures/entity/clothes.png");
    private final ModelPart torso,right,left,skirt,dress;
    private static ModelPart part(String name,ModelPartBuilder b){ModelData d=new ModelData();d.getRoot().addChild(name,b,ModelTransform.NONE);return TexturedModelData.of(d,64,64).createModel().getChild(name);}
    public GarmentFeature(FeatureRendererContext<AbstractClientPlayerEntity,PlayerEntityModel<AbstractClientPlayerEntity>> context){
        super(context);
        torso=part("torso",ModelPartBuilder.create().uv(16,16).cuboid(-4,0,-2,8,12,4,new Dilation(.55F)));
        right=part("right",ModelPartBuilder.create().uv(40,16).cuboid(-3,-2,-2,4,5,4,new Dilation(.5F)));
        left=part("left",ModelPartBuilder.create().uv(40,16).cuboid(-1,-2,-2,4,5,4,new Dilation(.5F)));
        skirt=part("skirt",ModelPartBuilder.create().uv(0,34).cuboid(-4.7F,11.8F,-2.7F,9.4F,3,5.4F).uv(0,46).cuboid(-5.3F,14.8F,-3.3F,10.6F,4,6.6F));
        dress=part("dress",ModelPartBuilder.create().uv(0,34).cuboid(-4.7F,11.8F,-2.7F,9.4F,4,5.4F).uv(0,46).cuboid(-5.5F,15.8F,-3.5F,11,5,7));
    }
    private void draw(MatrixStack m,VertexConsumer v,int light,ModelPart anchor,ModelPart mesh,int color){m.push();anchor.rotate(m);mesh.render(m,v,light,OverlayTexture.DEFAULT_UV,0xFF000000|color);m.pop();}
    @Override public void render(MatrixStack m,VertexConsumerProvider consumers,int light,AbstractClientPlayerEntity p,float a,float b,float delta,float age,float yaw,float pitch){
        if(p.isInvisible()||!(p instanceof WardrobeView view))return;
        var v=consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));var model=getContextModel();
        ItemStack top=view.softdiaper$getTop();
        if(top.getItem() instanceof GarmentItem g){
            draw(m,v,light,model.body,torso,g.color);draw(m,v,light,model.rightArm,right,g.color);draw(m,v,light,model.leftArm,left,g.color);
            if(g.kind==GarmentItem.Kind.DRESS)draw(m,v,light,model.body,dress,g.color);
        }
        if(view.softdiaper$getSkirt().getItem() instanceof GarmentItem g)draw(m,v,light,model.body,skirt,g.color);
    }
}
