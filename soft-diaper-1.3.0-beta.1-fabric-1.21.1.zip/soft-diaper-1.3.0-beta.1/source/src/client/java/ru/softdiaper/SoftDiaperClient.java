package ru.softdiaper;
import com.google.gson.JsonParser;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.client.item.ModelPredicateProviderRegistry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import ru.softdiaper.network.*;
public final class SoftDiaperClient implements ClientModInitializer {
    @Override public void onInitializeClient(){
        EntityRendererRegistry.register(NurseryContent.SEAT,SeatRenderer::new);
        EntityRendererRegistry.register(CareContent.TABLE_SEAT,ChangingSeatRenderer::new);
        for(var item:CareContent.DIAPERS.values()){
            ModelPredicateProviderRegistry.register(item,SoftDiaperMod.id("fullness"),(stack,world,entity,seed)->NurseryContent.fullness(stack)/100.0F);
            ModelPredicateProviderRegistry.register(item,SoftDiaperMod.id("wetness"),(stack,world,entity,seed)->SoftDiaperMod.wetness(stack)/100.0F);
        }
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type,renderer,helper,context)->{
            if(renderer instanceof PlayerEntityRenderer playerRenderer){helper.register(new PacifierFeature(playerRenderer));helper.register(new GarmentFeature(playerRenderer));}
        });
        KeyBinding key=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.softdiaper.menu",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_G,"key.categories.softdiaper"));
        ClientTickEvents.END_CLIENT_TICK.register(client->{while(key.wasPressed())if(client.player!=null&&ClientPlayNetworking.canSend(ActionPayload.ID))ClientPlayNetworking.send(new ActionPayload("open",""));});
        ClientPlayNetworking.registerGlobalReceiver(MenuPayload.ID,(payload,ctx)->ctx.client().execute(()->{
            var data=JsonParser.parseString(payload.json()).getAsJsonObject();
            if(ctx.client().currentScreen instanceof NurseryScreen screen)screen.update(data);
            else if(payload.open())ctx.client().setScreen(new NurseryScreen(data));
        }));
    }
}
