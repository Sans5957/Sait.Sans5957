package ru.softdiaper;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.util.Identifier;
public final class SeatRenderer extends EntityRenderer<SeatEntity> {
    public SeatRenderer(EntityRendererFactory.Context ctx) { super(ctx); shadowRadius=0; }
    @Override public Identifier getTexture(SeatEntity entity) { return SoftDiaperMod.id("textures/block/chair_wood.png"); }
    // Intentionally no geometry: the visible chair is a block model.
}
