package ru.softdiaper.mixin;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.*;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.softdiaper.care.CarePose;
@Mixin(PlayerEntityModel.class)
public abstract class CareModelMixin extends BipedEntityModel<LivingEntity> {
    @Shadow public ModelPart jacket,leftSleeve,rightSleeve,leftPants,rightPants;
    public CareModelMixin(ModelPart root){super(root);}
    @Inject(method="setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V",at=@At("TAIL"))
    private void softdiaper$animate(LivingEntity entity,float limbAngle,float limbDistance,float age,float headYaw,float headPitch,CallbackInfo ci){
        if(!(entity instanceof CarePose pose)||pose.softdiaper$getPose()==0)return;
        int f=pose.softdiaper$getPose();
        if((f&CarePose.CARRYING)!=0){rightArm.pitch=-1.35F;leftArm.pitch=-1.35F;rightArm.yaw=-.5F;leftArm.yaw=.5F;rightArm.roll=.2F;leftArm.roll=-.2F;}
        if((f&CarePose.CARRIED)!=0){rightLeg.pitch=-.7F;leftLeg.pitch=-.85F;rightLeg.yaw=.15F;leftLeg.yaw=-.15F;rightArm.pitch=-.2F;leftArm.pitch=-.2F;head.pitch=.15F;}
        if((f&CarePose.ON_TABLE)!=0){rightLeg.pitch=-.15F;leftLeg.pitch=-.15F;rightArm.roll=.28F;leftArm.roll=-.28F;head.pitch=0;head.yaw=0;}
        if((f&CarePose.CHANGING)!=0){float wave=(float)Math.sin(age*.5F)*.18F;body.pitch=.16F;rightArm.pitch=-1.25F+wave;leftArm.pitch=-1.25F-wave;rightArm.yaw=-.22F;leftArm.yaw=.22F;head.pitch=.5F;}
        if((f&CarePose.FEEDING)!=0){rightArm.pitch=-1.4F+(float)Math.sin(age*.55F)*.18F;rightArm.yaw=-.18F;}
        if((f&CarePose.BEING_FED)!=0 && (f&CarePose.CARRIED)==0)head.pitch=-.12F;
        jacket.copyTransform(body);leftSleeve.copyTransform(leftArm);rightSleeve.copyTransform(rightArm);leftPants.copyTransform(leftLeg);rightPants.copyTransform(rightLeg);hat.copyTransform(head);
    }
}
