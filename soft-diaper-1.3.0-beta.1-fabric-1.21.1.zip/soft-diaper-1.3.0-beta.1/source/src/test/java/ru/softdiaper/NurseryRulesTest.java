package ru.softdiaper;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class NurseryRulesTest {
    @Test void breadAdds20() { assertEquals(20,NurseryRules.afterMeal(0,5,false)); }
    @Test void steakAdds29() { assertEquals(29,NurseryRules.afterMeal(0,8,false)); }
    @Test void laxativeDoublesMeal() { assertEquals(40,NurseryRules.afterMeal(0,5,true)); }
    @Test void fullnessCapsAt100() { assertEquals(100,NurseryRules.afterMeal(90,8,true)); }
    @Test void pulseAdds5() { assertEquals(55,NurseryRules.afterLaxativeTick(50)); }
    @Test void pulseCapsAt100() { assertEquals(100,NurseryRules.afterLaxativeTick(99)); }
    @Test void freshnessRemoves40() { assertEquals(35,NurseryRules.freshen(75)); }
    @Test void freshnessCannotGoNegative() { assertEquals(0,NurseryRules.freshen(25)); }
    @Test void negativeNutritionHandled() { assertEquals(5,NurseryRules.afterMeal(0,-3,false)); }
    @Test void extremeNutritionCapped() { assertEquals(65,NurseryRules.afterMeal(0,Integer.MAX_VALUE,false)); }
    @Test void penaltyDoesNotStack() { assertEquals(0.25,NurseryRules.speedPenalty(100,100)); }
    @Test void wetPenaltyPreserved() { assertEquals(0.15,NurseryRules.speedPenalty(100,99)); }
    @Test void noPenaltyForPartlyFull() { assertEquals(0,NurseryRules.speedPenalty(99,99)); }
    @Test void fullDiaperCannotCushion() { assertFalse(NurseryRules.canCushion(0,100,3)); }
    @Test void partlyFullCanCushion() { assertTrue(NurseryRules.canCushion(0,99,3)); }
}
