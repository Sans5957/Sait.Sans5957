package ru.softdiaper;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DiaperRulesTest {
    @Test void clamps() { assertEquals(0, DiaperRules.clamp(-2)); assertEquals(100, DiaperRules.clamp(400)); }
    @Test void waterAdds20() { assertEquals(20, DiaperRules.afterWeather(0,true,false)); }
    @Test void rainAdds5() { assertEquals(55, DiaperRules.afterWeather(50,false,true)); }
    @Test void waterTakesPriorityOverRain() { assertEquals(40, DiaperRules.afterWeather(20,true,true)); }
    @Test void airDries5() { assertEquals(45, DiaperRules.afterWeather(50,false,false)); }
    @Test void weatherClamps() {
        assertEquals(100, DiaperRules.afterWeather(95,true,false));
        assertEquals(0, DiaperRules.afterWeather(2,false,false));
    }
    @Test void paperDries50() {
        assertEquals(50, DiaperRules.dryWithPaper(100));
        assertEquals(0, DiaperRules.dryWithPaper(30));
    }
    @Test void cushionOnlyBelow50() {
        assertTrue(DiaperRules.cushions(49,3)); assertFalse(DiaperRules.cushions(50,3));
    }
    @Test void cushionNeverStopsLargeFalls() {
        assertFalse(DiaperRules.cushions(0,4)); assertFalse(DiaperRules.cushions(0,100));
    }
    @Test void cushionRequiresPositiveDamage() {
        assertFalse(DiaperRules.cushions(0,0)); assertTrue(DiaperRules.cushions(0,1));
    }
}
