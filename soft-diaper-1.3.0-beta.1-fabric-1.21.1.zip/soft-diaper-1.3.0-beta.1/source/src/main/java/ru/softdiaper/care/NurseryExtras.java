package ru.softdiaper.care;
import java.util.*;
import net.fabricmc.fabric.api.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.item.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.*;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import ru.softdiaper.*;
/** Server-authoritative cosmetic inventory and explicit, expiring child consent. */
public final class NurseryExtras {
    public record Request(ServerPlayerEntity nanny,ServerPlayerEntity child,String kind,ItemStack expected,int slot,int expires){}
    private static final Map<UUID,Request> PENDING=new HashMap<>();
    private static final Map<UUID,Integer> COOLDOWN=new HashMap<>();
    public static Request pending(ServerPlayerEntity c){return PENDING.get(c.getUuid());}
    public static WardrobeStore.State state(ServerPlayerEntity p){return WardrobeStore.get(p.getServer()).state(p.getUuid());}
    public static void sync(ServerPlayerEntity p){var s=state(p);((WardrobeView)p).softdiaper$setClothes(s.top,s.skirt);}
    private static void dirty(ServerPlayerEntity p){WardrobeStore.get(p.getServer()).markDirty();sync(p);p.getInventory().markDirty();p.currentScreenHandler.sendContentUpdates();}
    public static void cancel(ServerPlayerEntity p){PENDING.values().removeIf(r->r.nanny()==p||r.child()==p);}
    public static void init(){
        ServerTickEvents.END_SERVER_TICK.register(server->{
            PENDING.values().removeIf(r->!valid(r)||r.child().isSneaking()||r.nanny().isSneaking());
            for(var p:server.getPlayerManager().getPlayerList()){
                sync(p);
                if(server.getTicks()%1200==0&&RoleStore.get(server).role(p.getUuid())==RoleStore.Role.CHILD){var s=state(p);s.mood=Math.max(0,s.mood-1);s.clean=Math.max(0,s.clean-1);WardrobeStore.get(server).markDirty();}
            }
        });
        ServerPlayConnectionEvents.DISCONNECT.register((h,s)->{cancel(h.player);COOLDOWN.remove(h.player.getUuid());});
        ServerLifecycleEvents.SERVER_STOPPED.register(s->{PENDING.clear();COOLDOWN.clear();});
    }
    public static boolean wear(ServerPlayerEntity owner,ServerPlayerEntity giver,boolean lower){
        if(RoleStore.get(owner.getServer()).role(owner.getUuid())!=RoleStore.Role.CHILD)return false;
        ItemStack hand=giver.getMainHandStack();
        if(!(hand.getItem() instanceof GarmentItem g)||(g.kind==GarmentItem.Kind.SKIRT)!=lower){CareManager.notice(giver,"need_garment");return false;}
        var s=state(owner);
        if(lower && s.top.getItem() instanceof GarmentItem top && top.kind==GarmentItem.Kind.DRESS){CareManager.notice(giver,"remove_dress");return false;}
        ItemStack previous=lower?s.skirt:s.top,replacement=hand.split(1);
        if(lower)s.skirt=replacement;else s.top=replacement;
        if(g.kind==GarmentItem.Kind.DRESS&&!s.skirt.isEmpty()){owner.getInventory().offerOrDrop(s.skirt);s.skirt=ItemStack.EMPTY;}
        if(!previous.isEmpty())owner.getInventory().offerOrDrop(previous);
        dirty(owner);giver.getInventory().markDirty();giver.currentScreenHandler.sendContentUpdates();CareManager.notice(owner,"dressed");return true;
    }
    public static void remove(ServerPlayerEntity owner,boolean lower){
        var s=state(owner);ItemStack old=lower?s.skirt:s.top;
        if(lower)s.skirt=ItemStack.EMPTY;else s.top=ItemStack.EMPTY;
        if(!old.isEmpty())owner.getInventory().offerOrDrop(old);dirty(owner);
    }
    private static boolean throttle(ServerPlayerEntity p){int now=p.getServer().getTicks();if(now<COOLDOWN.getOrDefault(p.getUuid(),-1)){CareManager.notice(p,"wait");return false;}COOLDOWN.put(p.getUuid(),now+100);return true;}
    public static boolean request(ServerPlayerEntity n,ServerPlayerEntity c,String kind){
        if(!Set.of("dress","wash","play","bed").contains(kind)||!CareManager.require(n,c)||CareManager.action(c)!=null)return false;
        ItemStack hand=n.getMainHandStack();
        if(kind.equals("dress")&&!(hand.getItem() instanceof GarmentItem)){CareManager.notice(n,"need_garment");return false;}
        if(kind.equals("wash")&&!hand.isOf(NurseryContent.WIPES)){CareManager.notice(n,"need_wipe_hand");return false;}
        if(kind.equals("play")&&!hand.isOf(PlayContent.RATTLE)){CareManager.notice(n,"need_rattle");return false;}
        if(!throttle(n))return false;
        PENDING.put(c.getUuid(),new Request(n,c,kind,hand.copy(),n.getInventory().selectedSlot,n.getServer().getTicks()+600));
        n.sendMessage(Text.translatable("care.softdiaper.offered",c.getName()),false);
        c.sendMessage(Text.translatable("care.softdiaper.offer",n.getName(),Text.translatable("extra.softdiaper."+kind)),false);
        CareManager.notice(c,"consent_needed");return true;
    }
    private static boolean valid(Request r){
        if(r.nanny().isRemoved()||r.child().isRemoved()||r.nanny().getServer().getTicks()>r.expires()||!CareManager.canCare(r.nanny(),r.child())||CareManager.action(r.child())!=null)return false;
        return r.kind().equals("bed") || (r.nanny().getInventory().selectedSlot==r.slot()&&ItemStack.areItemsAndComponentsEqual(r.nanny().getMainHandStack(),r.expected())&&!r.nanny().getMainHandStack().isEmpty());
    }
    public static boolean accept(ServerPlayerEntity c){
        Request r=PENDING.remove(c.getUuid());
        if(r==null||!valid(r)||!CareManager.require(r.nanny(),c)||c.isSneaking()||r.nanny().isSneaking()){CareManager.notice(c,"offer_expired");return false;}
        var n=r.nanny();var s=state(c);
        switch(r.kind()){
            case "dress" -> {var g=(GarmentItem)n.getMainHandStack().getItem();return wear(c,n,g.kind==GarmentItem.Kind.SKIRT);}
            case "wash" -> {n.getMainHandStack().decrement(1);s.clean=Math.min(100,s.clean+35);s.mood=Math.min(100,s.mood+5);
                c.getServerWorld().spawnParticles(ParticleTypes.SPLASH,c.getX(),c.getY()+1,c.getZ(),15,.3,.3,.3,.1);CareManager.notice(c,"washed");}
            case "play" -> {s.mood=Math.min(100,s.mood+20);c.getServerWorld().spawnParticles(ParticleTypes.HEART,c.getX(),c.getY()+1.5,c.getZ(),4,.3,.2,.3,0);
                c.getWorld().playSound(null,c.getBlockPos(),SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(),SoundCategory.PLAYERS,.5F,1.4F);CareManager.notice(c,"played");}
            case "bed" -> {CareManager.interrupt(c);CareManager.sleepNearby(c);return c.isSleeping();}
            default -> {return false;}
        }
        dirty(c);n.getInventory().markDirty();n.currentScreenHandler.sendContentUpdates();return true;
    }
    public static boolean rattle(ServerPlayerEntity p,Hand hand){
        if(RoleStore.get(p.getServer()).role(p.getUuid())!=RoleStore.Role.CHILD||!p.getStackInHand(hand).isOf(PlayContent.RATTLE)||p.getItemCooldownManager().isCoolingDown(PlayContent.RATTLE))return false;
        var s=state(p);s.mood=Math.min(100,s.mood+5);dirty(p);p.getItemCooldownManager().set(PlayContent.RATTLE,100);
        p.getWorld().playSound(null,p.getBlockPos(),SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(),SoundCategory.PLAYERS,.45F,1.5F);return true;
    }
    public static boolean self(ServerPlayerEntity p,String op){
        if(op.equals("remove_upper")||op.equals("remove_lower")){remove(p,op.equals("remove_lower"));return true;}
        if(RoleStore.get(p.getServer()).role(p.getUuid())!=RoleStore.Role.CHILD)return false;
        switch(op){
            case "wear_upper","wear_lower" -> wear(p,p,op.equals("wear_lower"));
            case "accept" -> accept(p);
            case "reject" -> {PENDING.remove(p.getUuid());CareManager.notice(p,"cancelled");}
            case "toy" -> {if(!rattle(p,Hand.MAIN_HAND))CareManager.notice(p,"need_rattle");}
            case "request_food","request_play","request_wash","request_bed" -> {
                var store=RoleStore.get(p.getServer());UUID id=store.guardian(p.getUuid());var n=id==null?null:p.getServer().getPlayerManager().getPlayer(id);
                if(n==null)CareManager.notice(p,"need_nanny");else if(throttle(p)){n.sendMessage(Text.translatable("care.softdiaper."+op,p.getName()),false);CareManager.notice(p,"request_sent");}
            }
            default -> {return false;}
        }return true;
    }
}
