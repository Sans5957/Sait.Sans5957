package ru.softdiaper;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.world.World;
import java.util.List;

public final class PillItem extends Item {
    private final boolean laxative;
    public PillItem(boolean laxative) { super(new Settings().maxCount(16)); this.laxative=laxative; }
    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        user.setCurrentHand(hand);
        return TypedActionResult.consume(user.getStackInHand(hand));
    }
    @Override public UseAction getUseAction(ItemStack stack) { return UseAction.EAT; }
    @Override public int getMaxUseTime(ItemStack stack, LivingEntity user) { return 32; }
    @Override public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        if (!world.isClient && user instanceof PlayerEntity player) {
            if (laxative) {
                player.addStatusEffect(new StatusEffectInstance(NurseryContent.LAXATIVE_EFFECT,1200,0,false,false,true));
                player.sendMessage(Text.translatable("message.softdiaper.laxative"),true);
            } else {
                player.removeStatusEffect(NurseryContent.LAXATIVE_EFFECT);
                ItemStack diaper = player.getEquippedStack(EquipmentSlot.LEGS);
                if (SoftDiaperMod.isDiaper(diaper))
                    NurseryContent.setFullness(player,diaper,NurseryRules.freshen(NurseryContent.fullness(diaper)));
                player.sendMessage(Text.translatable("message.softdiaper.freshness"),true);
            }
            player.getItemCooldownManager().set(this,100);
            if (!player.isCreative()) stack.decrement(1);
        }
        return stack;
    }
    @Override public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable(laxative ? "tooltip.softdiaper.laxative" : "tooltip.softdiaper.freshness").formatted(Formatting.LIGHT_PURPLE));
        tooltip.add(Text.translatable("tooltip.softdiaper.fictional").formatted(Formatting.GRAY));
    }
}
