package ru.softdiaper.mixin;
import net.minecraft.entity.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.softdiaper.care.CarePose;
@Mixin(Entity.class)
public abstract class CarryPositionMixin {
    @Inject(method="updatePassengerPosition(Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/Entity$PositionUpdater;)V",at=@At("HEAD"),cancellable=true)
    private void softdiaper$cradle(Entity passenger, Entity.PositionUpdater updater, CallbackInfo ci) {
        Entity self=(Entity)(Object)this;
        if(self instanceof PlayerEntity && passenger instanceof PlayerEntity && self.hasPassenger(passenger)
                && CarePose.has(self,CarePose.CARRYING) && CarePose.has(passenger,CarePose.CARRIED)) {
            Vec3d offset=new Vec3d(0,0.65,0.65).rotateY((float)Math.toRadians(-self.getYaw()));
            updater.accept(passenger,self.getX()+offset.x,self.getY()+offset.y,self.getZ()+offset.z);
            passenger.setYaw(self.getYaw());
            ci.cancel();
        }
    }
}
