package ru.softdiaper;
import net.minecraft.item.Item;
public final class GarmentItem extends Item {
    public enum Kind { SHIRT, DRESS, SKIRT }
    public final Kind kind;
    public final int color;
    public GarmentItem(Kind kind,int color){super(new Settings().maxCount(1));this.kind=kind;this.color=color;}
}
