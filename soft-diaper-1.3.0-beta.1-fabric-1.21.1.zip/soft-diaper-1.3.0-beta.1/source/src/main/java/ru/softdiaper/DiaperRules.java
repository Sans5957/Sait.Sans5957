package ru.softdiaper;

/** Pure gameplay rules. Wetness is an integer percentage. */
public final class DiaperRules {
    private DiaperRules() {}
    public static int clamp(int value) { return Math.max(0, Math.min(100, value)); }
    public static int afterWeather(int wetness, boolean inWater, boolean inRain) {
        return clamp(clamp(wetness) + (inWater ? 20 : inRain ? 5 : -5));
    }
    public static int dryWithPaper(int wetness) { return clamp(clamp(wetness) - 50); }
    public static boolean cushions(int wetness, float damage) {
        return clamp(wetness) < 50 && damage > 0 && damage <= 3.0F;
    }
}
