package ru.softdiaper;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.*;
import net.minecraft.world.*;

/** TallPlantBlock supplies proven two-part placement, break/drop and neighbor handling. */
public final class HighChairBlock extends TallPlantBlock {
    public static final MapCodec<TallPlantBlock> CODEC = createCodec(HighChairBlock::new);
    public static final DirectionProperty FACING = Properties.HORIZONTAL_FACING;
    public HighChairBlock(Settings settings) {
        super(settings);
        setDefaultState(getDefaultState().with(FACING,Direction.NORTH).with(HALF,DoubleBlockHalf.LOWER));
    }
    @Override public MapCodec<TallPlantBlock> getCodec() { return CODEC; }
    @Override protected void appendProperties(StateManager.Builder<Block,BlockState> builder) {
        super.appendProperties(builder); builder.add(FACING);
    }
    @Override public BlockState getPlacementState(ItemPlacementContext ctx) {
        BlockState state = super.getPlacementState(ctx);
        return state == null ? null : state.with(FACING,ctx.getHorizontalPlayerFacing().getOpposite());
    }
    @Override public void onPlaced(World world, BlockPos pos, BlockState state, net.minecraft.entity.LivingEntity placer, net.minecraft.item.ItemStack stack) {
        world.setBlockState(pos.up(),state.with(HALF,DoubleBlockHalf.UPPER),Block.NOTIFY_ALL);
    }
    @Override protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        if (state.get(HALF)==DoubleBlockHalf.UPPER) {
            BlockState below=world.getBlockState(pos.down());
            return below.isOf(this) && below.get(HALF)==DoubleBlockHalf.LOWER;
        }
        return world.getBlockState(pos.down()).isSideSolidFullSquare(world,pos.down(),Direction.UP);
    }
    @Override protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (player.isSneaking() || player.isSpectator() || player.hasVehicle()) return ActionResult.PASS;
        BlockPos base = state.get(HALF)==DoubleBlockHalf.UPPER ? pos.down() : pos;
        if (world.isClient) return ActionResult.SUCCESS;
        if (!world.getEntitiesByClass(SeatEntity.class,new Box(base).expand(0.2),e -> true).isEmpty()) {
            player.sendMessage(Text.translatable("message.softdiaper.chair_occupied"),true);
            return ActionResult.CONSUME;
        }
        SeatEntity seat = new SeatEntity(NurseryContent.SEAT,world);
        seat.setPosition(base.getX()+0.5,base.getY()+0.80,base.getZ()+0.5);
        seat.setYaw(state.get(FACING).asRotation());
        world.spawnEntity(seat);
        if (!player.startRiding(seat,true)) seat.discard();
        else {
            player.setYaw(seat.getYaw());
            player.sendMessage(Text.translatable("message.softdiaper.chair"),true);
        }
        return ActionResult.CONSUME;
    }
    private VoxelShape shape(BlockState state) {
        if (state.get(HALF)==DoubleBlockHalf.LOWER)
            return VoxelShapes.union(createCuboidShape(1,0,1,4,12,4),createCuboidShape(12,0,1,15,12,4),
                createCuboidShape(1,0,12,4,12,15),createCuboidShape(12,0,12,15,12,15),
                createCuboidShape(1,12,1,15,15,15));
        VoxelShape north=VoxelShapes.union(createCuboidShape(1,0,12,15,13,15),
            createCuboidShape(0,4,0,16,6,6),createCuboidShape(0,0,4,2,6,13),createCuboidShape(14,0,4,16,6,13));
        return ShapeUtil.rotate(north,state.get(FACING));
    }
    @Override protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) { return shape(state); }
    @Override protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        // An occupied chair must not push its rider out of the seat.
        if (context instanceof EntityShapeContext c && c.getEntity()!=null && c.getEntity().getVehicle() instanceof SeatEntity)
            return VoxelShapes.empty();
        return shape(state);
    }
}
