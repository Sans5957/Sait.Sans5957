package ru.softdiaper;
import net.minecraft.entity.*;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.*;
import net.minecraft.world.World;
public final class ChangingSeatEntity extends Entity {
    private BlockPos anchor=BlockPos.ORIGIN;
    public ChangingSeatEntity(EntityType<? extends ChangingSeatEntity> type,World world){super(type,world);setNoGravity(true);}
    public void setAnchor(BlockPos pos){anchor=pos.toImmutable();}
    @Override protected void initDataTracker(DataTracker.Builder builder){}
    @Override protected void readCustomDataFromNbt(NbtCompound nbt){anchor=BlockPos.fromLong(nbt.getLong("anchor"));}
    @Override protected void writeCustomDataToNbt(NbtCompound nbt){nbt.putLong("anchor",anchor.asLong());}
    @Override public void tick(){super.tick();if(!getWorld().isClient&&(!hasPassengers()||!getWorld().getBlockState(anchor).isOf(CareContent.CHANGING_TABLE)))discard();}
    @Override protected void updatePassengerPosition(Entity passenger,PositionUpdater updater){if(hasPassenger(passenger))updater.accept(passenger,getX(),getY(),getZ());}
    @Override public boolean isCollidable(){return false;}
    @Override protected boolean canAddPassenger(Entity passenger){return getPassengerList().isEmpty();}
    @Override public Vec3d updatePassengerForDismount(LivingEntity passenger){return Vec3d.ofBottomCenter(anchor.offset(getHorizontalFacing().rotateYClockwise()));}
}
