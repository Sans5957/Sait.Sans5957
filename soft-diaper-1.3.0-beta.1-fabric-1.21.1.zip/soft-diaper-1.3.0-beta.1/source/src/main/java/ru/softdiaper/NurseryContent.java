package ru.softdiaper;

import com.mojang.serialization.Codec;
import net.minecraft.block.*;
import net.minecraft.component.ComponentType;
import net.minecraft.entity.*;
import net.minecraft.entity.effect.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.*;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.block.piston.PistonBehavior;
import java.util.List;
import java.util.Map;

public final class NurseryContent {
    private NurseryContent() {}
    public static final ComponentType<Integer> FULLNESS = Registry.register(Registries.DATA_COMPONENT_TYPE,
        SoftDiaperMod.id("fullness"), ComponentType.<Integer>builder()
            .codec(Codec.intRange(0,100)).packetCodec(PacketCodecs.VAR_INT).build());

    public static final RegistryEntry<StatusEffect> LAXATIVE_EFFECT = Registry.registerReference(
        Registries.STATUS_EFFECT, SoftDiaperMod.id("laxative"), new GameEffect());

    public static final Item LAXATIVE = item("laxative", new PillItem(true));
    public static final Item FRESHNESS_PILL = item("freshness_pill", new PillItem(false));
    public static final Item WIPES = item("wipes", new WipesItem());

    public static final RegistryEntry<ArmorMaterial> PAJAMA_MATERIAL = material("pajamas");
    public static final RegistryEntry<ArmorMaterial> PACIFIER_MATERIAL = material("pacifier");
    public static final Item PAJAMAS = item("pajamas", new CozyArmorItem(PAJAMA_MATERIAL, ArmorItem.Type.CHESTPLATE, "pajamas"));
    public static final Item SLIPPERS = item("slippers", new CozyArmorItem(PAJAMA_MATERIAL, ArmorItem.Type.BOOTS, "slippers"));
    public static final Item PACIFIER = item("pacifier", new CozyArmorItem(PACIFIER_MATERIAL, ArmorItem.Type.HELMET, "pacifier"));

    public static final Block HIGH_CHAIR = Registry.register(Registries.BLOCK, SoftDiaperMod.id("high_chair"),
        new HighChairBlock(AbstractBlock.Settings.create().strength(1.5F).sounds(BlockSoundGroup.WOOD)
            .nonOpaque().pistonBehavior(PistonBehavior.DESTROY)));
    public static final Block CRIB = Registry.register(Registries.BLOCK, SoftDiaperMod.id("crib"),
        new CribBlock(AbstractBlock.Settings.create().strength(1.0F).sounds(BlockSoundGroup.WOOD)
            .nonOpaque().pistonBehavior(PistonBehavior.DESTROY)));
    public static final Item HIGH_CHAIR_ITEM = item("high_chair", new BlockItem(HIGH_CHAIR, new Item.Settings()));
    public static final Item CRIB_ITEM = item("crib", new BlockItem(CRIB, new Item.Settings().maxCount(1)));

    public static final EntityType<SeatEntity> SEAT = Registry.register(Registries.ENTITY_TYPE, SoftDiaperMod.id("seat"),
        EntityType.Builder.<SeatEntity>create(SeatEntity::new, SpawnGroup.MISC).dimensions(0.1F,0.1F)
            .maxTrackingRange(8).trackingTickInterval(10).disableSaving().build("softdiaper:seat"));

    public static final List<Item> ALL_ITEMS = List.of(SoftDiaperMod.DIAPER, LAXATIVE, FRESHNESS_PILL,
        WIPES, HIGH_CHAIR_ITEM, CRIB_ITEM, PAJAMAS, SLIPPERS, PACIFIER);

    private static Item item(String id, Item item) { return Registry.register(Registries.ITEM, SoftDiaperMod.id(id), item); }
    private static RegistryEntry<ArmorMaterial> material(String texture) {
        return Registry.registerReference(Registries.ARMOR_MATERIAL, SoftDiaperMod.id(texture), new ArmorMaterial(
            Map.of(ArmorItem.Type.HELMET,0, ArmorItem.Type.CHESTPLATE,0, ArmorItem.Type.LEGGINGS,0,
                ArmorItem.Type.BOOTS,0, ArmorItem.Type.BODY,0),
            0, SoundEvents.ITEM_ARMOR_EQUIP_LEATHER, () -> Ingredient.ofItems(Items.WHITE_WOOL),
            List.of(new ArmorMaterial.Layer(SoftDiaperMod.id(texture))), 0, 0));
    }
    public static void init() {}
    public static int fullness(ItemStack diaper) { return DiaperRules.clamp(diaper.getOrDefault(FULLNESS,0)); }
    public static void setFullness(PlayerEntity player, ItemStack diaper, int value) {
        int old = fullness(diaper), next = DiaperRules.clamp(value);
        diaper.set(FULLNESS,next);
        if (old < 100 && next == 100) player.sendMessage(Text.translatable("message.softdiaper.full").formatted(Formatting.GOLD),true);
    }
    public static void onFoodEaten(PlayerEntity player, int nutrition) {
        if (player.isSpectator()) return;
        ItemStack diaper = player.getEquippedStack(EquipmentSlot.LEGS);
        if (!SoftDiaperMod.isDiaper(diaper)) return;
        int next = NurseryRules.afterMeal(fullness(diaper),nutrition,player.hasStatusEffect(LAXATIVE_EFFECT));
        setFullness(player,diaper,next);
        if (next < 100) player.sendMessage(Text.translatable("message.softdiaper.meal",next),true);
    }
    public static void tick(PlayerEntity player, ItemStack diaper, boolean wearing) {
        if (wearing && player.age % 100 == 0 && player.hasStatusEffect(LAXATIVE_EFFECT)) {
            setFullness(player,diaper,NurseryRules.afterLaxativeTick(fullness(diaper)));
        }
        // A small fictional rest bonus. Hunger cost prevents infinite free healing.
        if (player.age % 200 == 0 && !player.isSpectator() && player.getWorld().isNight()
                && player.getEquippedStack(EquipmentSlot.CHEST).isOf(PAJAMAS)
                && player.getEquippedStack(EquipmentSlot.FEET).isOf(SLIPPERS)
                && player.getEquippedStack(EquipmentSlot.HEAD).isOf(PACIFIER)
                && (player.isSleeping() || player.isSneaking() || player.getVehicle() instanceof SeatEntity)
                && player.getVelocity().horizontalLengthSquared() < 0.001
                && player.getHungerManager().getFoodLevel() >= 6 && player.getHealth() < player.getMaxHealth()) {
            player.heal(1.0F);
            player.addExhaustion(1.0F);
        }
    }
    private static final class GameEffect extends StatusEffect {
        private GameEffect() { super(StatusEffectCategory.NEUTRAL, 0xCBA4EC); }
    }
}
