package ru.softdiaper.network;
import com.google.gson.*;
import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import ru.softdiaper.*;
import ru.softdiaper.care.*;
import java.util.*;
public final class CareNetworking {
    private static final Set<UUID> OPEN=new HashSet<>();
    private static final Map<UUID,Integer> LAST_PACKET=new HashMap<>();
    private CareNetworking(){}
    public static void init(){
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID,ActionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MenuPayload.ID,MenuPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID,(payload,context)->context.server().execute(()->{
            var p=context.player();int now=context.server().getTicks();
            if(payload.action().equals("close")){close(p);return;}
            if(now-LAST_PACKET.getOrDefault(p.getUuid(),-100)<2)return;LAST_PACKET.put(p.getUuid(),now);
            handle(p,payload);
        }));
    }
    public static void clear(){OPEN.clear();LAST_PACKET.clear();}
    public static void close(ServerPlayerEntity p){OPEN.remove(p.getUuid());LAST_PACKET.remove(p.getUuid());}
    public static void open(ServerPlayerEntity p){
        
        OPEN.add(p.getUuid());send(p,true);
    }
    public static void refresh(MinecraftServer server){for(UUID id:new ArrayList<>(OPEN)){var p=server.getPlayerManager().getPlayer(id);if(p==null)OPEN.remove(id);else send(p,false);}}
    public static JsonObject playerData(ServerPlayerEntity p,ServerPlayerEntity viewer){
        JsonObject d=new JsonObject();d.addProperty("id",p.getUuidAsString());d.addProperty("name",p.getName().getString());
        var diaper=p.getEquippedStack(EquipmentSlot.LEGS);boolean wearing=SoftDiaperMod.isDiaper(diaper);
        d.addProperty("diaper",wearing);d.addProperty("wet",wearing?SoftDiaperMod.wetness(diaper):0);d.addProperty("full",wearing?NurseryContent.fullness(diaper):0);
        d.addProperty("food",p.getHungerManager().getFoodLevel());d.addProperty("health",p.getHealth());
        d.addProperty("distance",p.getWorld()==viewer.getWorld()?(int)Math.ceil(p.distanceTo(viewer)):-1);
        d.addProperty("paused",RoleStore.get(p.getServer()).paused(p.getUuid()));
        d.addProperty("table",CareManager.table(p)!=null);d.addProperty("carried",CareManager.carried(p));
        var extra=NurseryExtras.state(p);
        d.addProperty("mood",extra.mood);d.addProperty("clean",extra.clean);
        d.addProperty("top",net.minecraft.registry.Registries.ITEM.getId(extra.top.getItem()).toString());
        d.addProperty("skirt",net.minecraft.registry.Registries.ITEM.getId(extra.skirt.getItem()).toString());
        var pending=NurseryExtras.pending(p);d.addProperty("offer",pending==null?"":pending.kind());
        var a=CareManager.action(p);d.addProperty("action",a==null?"":a.kind.name().toLowerCase());d.addProperty("progress",a==null?0:a.elapsed*100/a.total);return d;
    }
    public static void send(ServerPlayerEntity p,boolean open){
        if(!ServerPlayNetworking.canSend(p,MenuPayload.ID))return;
        RoleStore store=RoleStore.get(p.getServer());JsonObject data=new JsonObject();
        data.addProperty("role",store.role(p.getUuid()).name().toLowerCase());data.addProperty("notice",CareManager.lastNotice(p));data.add("self",playerData(p,p));
        UUID bound=store.guardian(p.getUuid());var guardian=bound==null?null:p.getServer().getPlayerManager().getPlayer(bound);
        data.addProperty("nanny",guardian==null?"":guardian.getName().getString());data.addProperty("bound",bound!=null);
        JsonArray children=new JsonArray();
        if(store.role(p.getUuid())==RoleStore.Role.NANNY){
            p.getServer().getPlayerManager().getPlayerList().stream().filter(c->store.linked(p.getUuid(),c.getUuid())).limit(64).forEach(c->children.add(playerData(c,p)));
        }
        data.add("children",children);ServerPlayNetworking.send(p,new MenuPayload(data.toString(),open));
    }
    public static void handle(ServerPlayerEntity p,ActionPayload payload){
        var store=RoleStore.get(p.getServer());String op=payload.action();
        if(op.equals("open")){open(p);return;}
        if(NurseryExtras.self(p,op)){send(p,false);return;}
        if(op.equals("stop")){CareManager.interrupt(p);CareManager.notice(p,"cancelled");send(p,false);return;}
        if(store.role(p.getUuid())==RoleStore.Role.CHILD){
            switch(op){
                case "pause" -> {store.setPaused(p.getUuid(),!store.paused(p.getUuid()));CareManager.interrupt(p);}
                case "call" -> {var n=store.guardian(p.getUuid())==null?null:p.getServer().getPlayerManager().getPlayer(store.guardian(p.getUuid()));
                    if(n!=null){n.sendMessage(Text.translatable("care.softdiaper.called",p.getName()),false);CareManager.notice(p,"called_ok");}else CareManager.notice(p,"need_nanny");}
                case "table" -> {var n=store.guardian(p.getUuid())==null?null:p.getServer().getPlayerManager().getPlayer(store.guardian(p.getUuid()));
                    if(n!=null)CareManager.layDown(n,p,CareManager.nearbyTable(p));else CareManager.notice(p,"need_nanny");}
                case "sleep" -> CareManager.sleepNearby(p);
            }
        }else if(store.role(p.getUuid())==RoleStore.Role.NANNY){
            ServerPlayerEntity child=null;try{child=p.getServer().getPlayerManager().getPlayer(UUID.fromString(payload.target()));}catch(IllegalArgumentException ignored){}
            if(child==null||!store.linked(p.getUuid(),child.getUuid())){CareManager.notice(p,"not_allowed");send(p,false);return;}
            switch(op){case "carry"->CareManager.carry(p,child);case "feed"->CareManager.startFeed(p,child);
                case "table"->CareManager.layDown(p,child,CareManager.nearbyTable(p));case "change"->CareManager.startChange(p,child);
                case "dress","wash","play","bed"->NurseryExtras.request(p,child,op);}
        }else CareManager.notice(p,"no_role");
        send(p,false);
    }
}
