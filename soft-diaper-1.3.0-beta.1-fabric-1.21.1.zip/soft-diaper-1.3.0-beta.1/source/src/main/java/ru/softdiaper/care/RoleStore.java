package ru.softdiaper.care;
import net.minecraft.nbt.*;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;
import java.util.*;

/** Server-owned role assignments, saved in the overworld's data/softdiaper_roles.dat. */
public final class RoleStore extends PersistentState {
    public enum Role { NONE, CHILD, NANNY }
    public static final Type<RoleStore> TYPE=new Type<>(RoleStore::new,RoleStore::read,null);
    private final Map<UUID,Role> roles=new HashMap<>();
    private final Map<UUID,UUID> guardians=new HashMap<>();
    private final Set<UUID> paused=new HashSet<>();
    public static RoleStore get(MinecraftServer server) {return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE,"softdiaper_roles");}
    public Role role(UUID id) { return roles.getOrDefault(id,Role.NONE); }
    public UUID guardian(UUID child) {return guardians.get(child);}
    public boolean paused(UUID child) {return paused.contains(child);}
    public void setPaused(UUID id,boolean value) {if(value)paused.add(id);else paused.remove(id);markDirty();}
    public boolean linked(UUID nanny,UUID child) {return role(nanny)==Role.NANNY && role(child)==Role.CHILD && nanny.equals(guardian(child));}
    public void setRole(UUID id,Role role) {
        if(role==Role.NONE)roles.remove(id);else roles.put(id,role);
        if(role!=Role.CHILD){guardians.remove(id);paused.remove(id);}
        if(role!=Role.NANNY)guardians.entrySet().removeIf(e->e.getValue().equals(id));
        markDirty();
    }
    public void bind(UUID child,UUID nanny) {
        if(role(child)!=Role.CHILD || role(nanny)!=Role.NANNY || child.equals(nanny))throw new IllegalArgumentException("Roles do not match");
        guardians.put(child,nanny);markDirty();
    }
    public void unbind(UUID child) {guardians.remove(child);markDirty();}
    @Override public NbtCompound writeNbt(NbtCompound nbt,RegistryWrapper.WrapperLookup lookup) {
        NbtList list=new NbtList();
        roles.forEach((id,role)->{NbtCompound e=new NbtCompound();e.putUuid("id",id);e.putString("role",role.name());
            if(guardians.containsKey(id))e.putUuid("nanny",guardians.get(id));e.putBoolean("paused",paused(id));list.add(e);});
        nbt.put("players",list);return nbt;
    }
    public static RoleStore read(NbtCompound nbt,RegistryWrapper.WrapperLookup lookup) {
        RoleStore store=new RoleStore();
        for(NbtElement value:nbt.getList("players",NbtElement.COMPOUND_TYPE)) {
            NbtCompound e=(NbtCompound)value;
            try {UUID id=e.getUuid("id");store.roles.put(id,Role.valueOf(e.getString("role")));
                if(e.containsUuid("nanny"))store.guardians.put(id,e.getUuid("nanny"));if(e.getBoolean("paused"))store.paused.add(id);
            }catch(IllegalArgumentException ignored){}
        }
        return store;
    }
}
