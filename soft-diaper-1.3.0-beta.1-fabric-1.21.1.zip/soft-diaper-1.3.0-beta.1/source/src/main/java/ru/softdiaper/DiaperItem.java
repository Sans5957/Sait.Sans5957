package ru.softdiaper;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.List;

public final class DiaperItem extends ArmorItem {
    public DiaperItem(RegistryEntry<ArmorMaterial> material, Settings settings) {
        super(material, Type.LEGGINGS, settings);
    }

    @Override public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        super.appendTooltip(stack, context, tooltip, type);
        int wetness = SoftDiaperMod.wetness(stack);
        int fullness = NurseryContent.fullness(stack);
        tooltip.add(Text.translatable("tooltip.softdiaper.fullness",fullness).formatted(fullness==100 ? Formatting.GOLD : Formatting.YELLOW));
        tooltip.add(Text.translatable("tooltip.softdiaper.clean").formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("tooltip.softdiaper.wetness", wetness)
            .formatted(wetness == 100 ? Formatting.RED : Formatting.AQUA));
        tooltip.add(Text.translatable(wetness < 50 && fullness < 100 ? "tooltip.softdiaper.cushion" : "tooltip.softdiaper.no_cushion")
            .formatted(wetness < 50 && fullness < 100 ? Formatting.GREEN : Formatting.GRAY));
        tooltip.add(Text.translatable("tooltip.softdiaper.paper").formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("tooltip.softdiaper.air").formatted(Formatting.GRAY));
        if (fullness == 100) tooltip.add(Text.translatable("tooltip.softdiaper.full_slow").formatted(Formatting.GOLD));
        else if (wetness == 100) tooltip.add(Text.translatable("tooltip.softdiaper.slow").formatted(Formatting.RED));
    }
}
