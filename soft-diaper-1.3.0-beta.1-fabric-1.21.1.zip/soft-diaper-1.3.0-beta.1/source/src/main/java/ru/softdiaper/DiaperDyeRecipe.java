package ru.softdiaper;
import net.minecraft.item.*;
import net.minecraft.recipe.*;
import net.minecraft.recipe.book.CraftingRecipeCategory;
import net.minecraft.recipe.input.CraftingRecipeInput;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.world.World;
public final class DiaperDyeRecipe extends SpecialCraftingRecipe {
    public DiaperDyeRecipe(CraftingRecipeCategory category) {super(category);}
    @Override public boolean matches(CraftingRecipeInput input,World world) {
        int diapers=0,dyes=0;
        for(int i=0;i<input.getSize();i++) {ItemStack s=input.getStackInSlot(i);if(s.isEmpty())continue;
            if(SoftDiaperMod.isDiaper(s))diapers++;else if(s.getItem() instanceof DyeItem)dyes++;else return false;}
        return diapers==1 && dyes==1;
    }
    @Override public ItemStack craft(CraftingRecipeInput input,RegistryWrapper.WrapperLookup lookup) {
        ItemStack diaper=ItemStack.EMPTY;DyeItem dye=null;
        for(int i=0;i<input.getSize();i++){ItemStack s=input.getStackInSlot(i);if(SoftDiaperMod.isDiaper(s))diaper=s;else if(s.getItem() instanceof DyeItem d)dye=d;}
        if(diaper.isEmpty()||dye==null)return ItemStack.EMPTY;
        // Preserve wetness, fullness, durability, name and enchantments; dyeing never cleans it.
        return diaper.copyComponentsToNewStack(CareContent.DIAPERS.get(dye.getColor()),1);
    }
    @Override public boolean fits(int width,int height){return width*height>=2;}
    @Override public RecipeSerializer<?> getSerializer(){return CareContent.DYE_RECIPE;}
}
