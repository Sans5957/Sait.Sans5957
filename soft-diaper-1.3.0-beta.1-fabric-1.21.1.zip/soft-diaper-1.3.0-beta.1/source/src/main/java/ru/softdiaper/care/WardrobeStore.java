package ru.softdiaper.care;
import java.util.*;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.*;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;
import ru.softdiaper.GarmentItem;
/** Cosmetic inventory is owned by UUID and retained on death, without copying into vanilla inventory. */
public final class WardrobeStore extends PersistentState {
    public static final Type<WardrobeStore> TYPE=new Type<>(WardrobeStore::new,WardrobeStore::read,null);
    public static final class State {
        public ItemStack top=ItemStack.EMPTY,skirt=ItemStack.EMPTY;
        public int mood=70,clean=100;
    }
    private final Map<UUID,State> players=new HashMap<>();
    public static WardrobeStore get(MinecraftServer s){return s.getOverworld().getPersistentStateManager().getOrCreate(TYPE,"softdiaper_wardrobe");}
    public State state(UUID id){return players.computeIfAbsent(id,k->{markDirty();return new State();});}
    @Override public NbtCompound writeNbt(NbtCompound nbt,RegistryWrapper.WrapperLookup lookup){
        NbtList list=new NbtList();players.forEach((id,s)->{NbtCompound v=new NbtCompound();v.putUuid("id",id);
            if(!s.top.isEmpty())v.put("top",s.top.encode(lookup));if(!s.skirt.isEmpty())v.put("skirt",s.skirt.encode(lookup));
            v.putInt("mood",s.mood);v.putInt("clean",s.clean);list.add(v);});nbt.put("players",list);return nbt;
    }
    public static WardrobeStore read(NbtCompound nbt,RegistryWrapper.WrapperLookup lookup){
        WardrobeStore store=new WardrobeStore();
        for(NbtElement el:nbt.getList("players",NbtElement.COMPOUND_TYPE)){
            NbtCompound v=(NbtCompound)el;if(!v.containsUuid("id"))continue;State s=new State();
            if(v.contains("top",NbtElement.COMPOUND_TYPE))s.top=ItemStack.fromNbt(lookup,v.getCompound("top")).orElse(ItemStack.EMPTY);
            if(v.contains("skirt",NbtElement.COMPOUND_TYPE))s.skirt=ItemStack.fromNbt(lookup,v.getCompound("skirt")).orElse(ItemStack.EMPTY);
            if(!(s.top.getItem() instanceof GarmentItem g)||g.kind==GarmentItem.Kind.SKIRT)s.top=ItemStack.EMPTY;
            if(!(s.skirt.getItem() instanceof GarmentItem g)||g.kind!=GarmentItem.Kind.SKIRT)s.skirt=ItemStack.EMPTY;
            s.mood=Math.clamp(v.getInt("mood"),0,100);s.clean=Math.clamp(v.getInt("clean"),0,100);store.players.put(v.getUuid("id"),s);
        }return store;
    }
}
