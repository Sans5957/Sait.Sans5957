package ru.softdiaper;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.*;
import net.minecraft.world.*;
import ru.softdiaper.care.CareManager;
public final class ChangingTableBlock extends BedBlock {
    public static final MapCodec<BedBlock> CODEC=createCodec(ChangingTableBlock::new);
    public ChangingTableBlock(Settings settings){super(DyeColor.CYAN,settings);}
    @Override public MapCodec<BedBlock> getCodec(){return CODEC;}
    @Override public BlockEntity createBlockEntity(BlockPos pos,BlockState state){return null;}
    @Override protected BlockRenderType getRenderType(BlockState state){return BlockRenderType.MODEL;}
    @Override protected ActionResult onUse(BlockState state,World world,BlockPos pos,PlayerEntity player,BlockHitResult hit){
        if(player instanceof ServerPlayerEntity p)CareManager.useTable(p,pos);
        return ActionResult.SUCCESS;
    }
    @Override protected VoxelShape getOutlineShape(BlockState s,BlockView w,BlockPos p,ShapeContext c){return createCuboidShape(0,0,0,16,16,16);}
    @Override protected VoxelShape getCollisionShape(BlockState s,BlockView w,BlockPos p,ShapeContext c){return createCuboidShape(0,0,0,16,16,16);}
}
