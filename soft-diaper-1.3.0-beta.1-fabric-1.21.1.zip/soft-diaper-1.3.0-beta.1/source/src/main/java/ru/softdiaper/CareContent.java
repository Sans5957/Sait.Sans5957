package ru.softdiaper;
import net.minecraft.block.*;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.recipe.*;
import net.minecraft.registry.*;
import net.minecraft.sound.*;
import net.minecraft.util.DyeColor;
import java.util.*;
public final class CareContent {
    private CareContent(){}
    public static final Map<DyeColor,Item> DIAPERS=new EnumMap<>(DyeColor.class);
    public static final List<Item> EXTRA_ITEMS=new ArrayList<>();
    public static final Block CHANGING_TABLE=Registry.register(Registries.BLOCK,SoftDiaperMod.id("changing_table"),new ChangingTableBlock(settings()));
    public static final Block CHILD_CRIB=Registry.register(Registries.BLOCK,SoftDiaperMod.id("child_crib"),new ChildCribBlock(settings()));
    public static final Item CHANGING_TABLE_ITEM=register("changing_table",new BlockItem(CHANGING_TABLE,new Item.Settings().maxCount(16)));
    public static final Item CHILD_CRIB_ITEM=register("child_crib",new BlockItem(CHILD_CRIB,new Item.Settings().maxCount(1)));
    public static final EntityType<ChangingSeatEntity> TABLE_SEAT=Registry.register(Registries.ENTITY_TYPE,SoftDiaperMod.id("changing_seat"),
        EntityType.Builder.<ChangingSeatEntity>create(ChangingSeatEntity::new,SpawnGroup.MISC).dimensions(.1F,.1F).maxTrackingRange(8).trackingTickInterval(5).disableSaving().build("softdiaper:changing_seat"));
    public static final RecipeSerializer<DiaperDyeRecipe> DYE_RECIPE=Registry.register(Registries.RECIPE_SERIALIZER,SoftDiaperMod.id("diaper_dye"),new SpecialRecipeSerializer<>(DiaperDyeRecipe::new));
    private static AbstractBlock.Settings settings(){return AbstractBlock.Settings.create().strength(1.5F).sounds(BlockSoundGroup.WOOD).nonOpaque().pistonBehavior(PistonBehavior.DESTROY);}
    private static Item register(String id,Item item){Registry.register(Registries.ITEM,SoftDiaperMod.id(id),item);EXTRA_ITEMS.add(item);return item;}
    public static void init(){
        DIAPERS.put(DyeColor.WHITE,SoftDiaperMod.DIAPER);
        for(DyeColor color:DyeColor.values()){
            if(color==DyeColor.WHITE)continue;
            var material=Registry.registerReference(Registries.ARMOR_MATERIAL,SoftDiaperMod.id("cotton_"+color.getName()),new ArmorMaterial(
                Map.of(ArmorItem.Type.HELMET,0,ArmorItem.Type.CHESTPLATE,0,ArmorItem.Type.LEGGINGS,1,ArmorItem.Type.BOOTS,0,ArmorItem.Type.BODY,0),
                10,SoundEvents.ITEM_ARMOR_EQUIP_LEATHER,()->Ingredient.ofItems(Items.WHITE_WOOL),
                List.of(new ArmorMaterial.Layer(SoftDiaperMod.id("cotton_"+color.getName()))),0,0));
            DIAPERS.put(color,register(color.getName()+"_diaper",new DiaperItem(material,new Item.Settings().maxDamage(120).component(SoftDiaperMod.WETNESS,0))));
        }
    }
}
