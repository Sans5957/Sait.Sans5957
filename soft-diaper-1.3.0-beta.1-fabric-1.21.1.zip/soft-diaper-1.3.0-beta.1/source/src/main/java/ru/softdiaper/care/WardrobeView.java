package ru.softdiaper.care;
import net.minecraft.item.ItemStack;
public interface WardrobeView {
    ItemStack softdiaper$getTop();
    ItemStack softdiaper$getSkirt();
    void softdiaper$setClothes(ItemStack top, ItemStack skirt);
}
