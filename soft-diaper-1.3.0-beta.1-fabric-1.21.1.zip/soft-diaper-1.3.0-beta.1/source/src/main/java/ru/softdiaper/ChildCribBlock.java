package ru.softdiaper;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import ru.softdiaper.care.*;
public final class ChildCribBlock extends CribBlock {
    public static final MapCodec<BedBlock> CODEC=createCodec(ChildCribBlock::new);
    public ChildCribBlock(Settings settings){super(settings);}
    @Override public MapCodec<BedBlock> getCodec(){return CODEC;}
    @Override protected ActionResult onUse(BlockState state,World world,BlockPos pos,PlayerEntity player,BlockHitResult hit){
        if(player instanceof ServerPlayerEntity p){
            if(RoleStore.get(p.getServer()).role(p.getUuid())!=RoleStore.Role.CHILD){CareManager.notice(p,"child_only");return ActionResult.FAIL;}
            if(p.hasVehicle()){CareManager.notice(p,"stand_first");return ActionResult.FAIL;}
        }
        return super.onUse(state,world,pos,player,hit);
    }
}
