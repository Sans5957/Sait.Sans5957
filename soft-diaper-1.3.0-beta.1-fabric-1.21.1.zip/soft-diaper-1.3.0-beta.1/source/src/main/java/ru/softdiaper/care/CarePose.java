package ru.softdiaper.care;
public interface CarePose {
    int CARRIED=1, CARRYING=2, ON_TABLE=4, CHANGING=8, BEING_FED=16, FEEDING=32;
    int softdiaper$getPose();
    void softdiaper$setPose(int pose);
    int softdiaper$getProgress();
    void softdiaper$setProgress(int progress);
    static boolean has(Object entity,int flag) { return entity instanceof CarePose p && (p.softdiaper$getPose() & flag)!=0; }
}
