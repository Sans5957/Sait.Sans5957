package ru.softdiaper.mixin;
import net.minecraft.block.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.softdiaper.NurseryContent;
@Mixin(CakeBlock.class)
public abstract class CakeConsumptionMixin {
    @Inject(method="tryEat",at=@At("RETURN"))
    private static void softdiaper$cake(WorldAccess world, BlockPos pos, BlockState state, PlayerEntity player,
            CallbackInfoReturnable<ActionResult> cir) {
        if (!world.isClient() && cir.getReturnValue().isAccepted()) NurseryContent.onFoodEaten(player,2);
    }
}
