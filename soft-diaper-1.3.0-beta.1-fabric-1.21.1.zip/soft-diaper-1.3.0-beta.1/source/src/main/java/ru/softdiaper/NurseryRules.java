package ru.softdiaper;

/** Fictional game mechanics; these are not medical effects or real doses. */
public final class NurseryRules {
    private NurseryRules() {}
    public static int afterMeal(int fullness, int nutrition, boolean laxative) {
        int amount = 5 + Math.min(20, Math.max(0, nutrition)) * 3;
        return DiaperRules.clamp(fullness + amount * (laxative ? 2 : 1));
    }
    public static int afterLaxativeTick(int fullness) { return DiaperRules.clamp(fullness + 5); }
    public static int freshen(int fullness) { return DiaperRules.clamp(fullness - 40); }
    public static double speedPenalty(int wetness, int fullness) {
        return fullness >= 100 ? 0.25 : wetness >= 100 ? 0.15 : 0;
    }
    public static boolean canCushion(int wetness, int fullness, float damage) {
        return fullness < 100 && DiaperRules.cushions(wetness, damage);
    }
}
