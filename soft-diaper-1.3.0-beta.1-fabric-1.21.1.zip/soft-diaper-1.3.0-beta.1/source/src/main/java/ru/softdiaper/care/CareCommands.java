package ru.softdiaper.care;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import ru.softdiaper.network.CareNetworking;
public final class CareCommands {
    private CareCommands(){}
    public static void init(){CommandRegistrationCallback.EVENT.register((dispatcher,registries,environment)->{
        var root=CommandManager.literal("nursery");
        root.executes(c->{CareNetworking.open(c.getSource().getPlayerOrThrow());return 1;});
        root.then(CommandManager.literal("gui").executes(c->{CareNetworking.open(c.getSource().getPlayerOrThrow());return 1;}));
        root.then(CommandManager.literal("release").executes(c->{CareManager.interrupt(c.getSource().getPlayerOrThrow());return 1;}));
        root.then(CommandManager.literal("accept").executes(c->NurseryExtras.accept(c.getSource().getPlayerOrThrow())?1:0));
        root.then(CommandManager.literal("reject").executes(c->{NurseryExtras.cancel(c.getSource().getPlayerOrThrow());return 1;}));
        var roles=CommandManager.literal("role").requires(s->s.hasPermissionLevel(2));
        var who=CommandManager.argument("player",EntityArgumentType.player());
        for(RoleStore.Role role:RoleStore.Role.values())who.then(CommandManager.literal(role.name().toLowerCase()).executes(c->{
            var p=EntityArgumentType.getPlayer(c,"player");CareManager.interrupt(p);RoleStore.get(c.getSource().getServer()).setRole(p.getUuid(),role);
            c.getSource().sendFeedback(()->Text.translatable("command.softdiaper.role",p.getName(),Text.translatable("role.softdiaper."+role.name().toLowerCase())),true);return 1;
        }));
        root.then(roles.then(who));
        root.then(CommandManager.literal("bind").requires(s->s.hasPermissionLevel(2))
            .then(CommandManager.argument("child",EntityArgumentType.player()).then(CommandManager.argument("nanny",EntityArgumentType.player()).executes(c->{
                var child=EntityArgumentType.getPlayer(c,"child");var nanny=EntityArgumentType.getPlayer(c,"nanny");var store=RoleStore.get(c.getSource().getServer());
                if(store.role(child.getUuid())!=RoleStore.Role.CHILD||store.role(nanny.getUuid())!=RoleStore.Role.NANNY){c.getSource().sendError(Text.translatable("care.softdiaper.assign_first"));return 0;}
                CareManager.interrupt(child);store.bind(child.getUuid(),nanny.getUuid());
                c.getSource().sendFeedback(()->Text.translatable("command.softdiaper.bound",child.getName(),nanny.getName()),true);return 1;
            }))));
        root.then(CommandManager.literal("unbind").requires(s->s.hasPermissionLevel(2)).then(CommandManager.argument("child",EntityArgumentType.player()).executes(c->{
            var child=EntityArgumentType.getPlayer(c,"child");CareManager.interrupt(child);RoleStore.get(c.getSource().getServer()).unbind(child.getUuid());
            c.getSource().sendFeedback(()->Text.translatable("command.softdiaper.unbound",child.getName()),true);return 1;
        })));
        dispatcher.register(root);
    });}
}
