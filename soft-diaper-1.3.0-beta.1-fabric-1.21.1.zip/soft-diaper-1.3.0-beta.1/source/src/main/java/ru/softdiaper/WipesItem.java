package ru.softdiaper;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.world.World;
import java.util.List;
public final class WipesItem extends Item {
    public WipesItem() { super(new Settings().maxCount(16)); }
    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack wipes=player.getStackInHand(hand), diaper=player.getEquippedStack(EquipmentSlot.LEGS);
        if (player.isSpectator() || !SoftDiaperMod.isDiaper(diaper)) return TypedActionResult.pass(wipes);
        if (NurseryContent.fullness(diaper)==0 && SoftDiaperMod.wetness(diaper)==0) return TypedActionResult.pass(wipes);
        if (!world.isClient) {
            diaper.set(NurseryContent.FULLNESS,0);
            diaper.set(SoftDiaperMod.WETNESS,DiaperRules.clamp(SoftDiaperMod.wetness(diaper)-25));
            if (!player.isCreative()) wipes.decrement(1);
            player.getItemCooldownManager().set(this,10);
            player.sendMessage(Text.translatable("message.softdiaper.wipes"),true);
        }
        return TypedActionResult.success(wipes,world.isClient);
    }
    @Override public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.softdiaper.wipes").formatted(Formatting.AQUA));
    }
}
