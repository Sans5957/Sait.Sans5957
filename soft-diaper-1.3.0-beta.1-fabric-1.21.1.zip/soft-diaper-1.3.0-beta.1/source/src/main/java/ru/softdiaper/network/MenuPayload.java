package ru.softdiaper.network;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.packet.CustomPayload;
import ru.softdiaper.SoftDiaperMod;
public record MenuPayload(String json,boolean open) implements CustomPayload {
    public static final Id<MenuPayload> ID=new Id<>(SoftDiaperMod.id("care_menu"));
    public static final PacketCodec<RegistryByteBuf,MenuPayload> CODEC=PacketCodec.tuple(PacketCodecs.string(32767),MenuPayload::json,PacketCodecs.BOOL,MenuPayload::open,MenuPayload::new);
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
