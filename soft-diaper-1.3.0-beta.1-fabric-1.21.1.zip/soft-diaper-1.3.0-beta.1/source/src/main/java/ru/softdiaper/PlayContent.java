package ru.softdiaper;
import java.util.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import net.minecraft.registry.*;
import net.minecraft.util.*;
import net.minecraft.server.network.ServerPlayerEntity;
import ru.softdiaper.care.NurseryExtras;
public final class PlayContent {
    public static final Map<String,GarmentItem> CLOTHES=new LinkedHashMap<>();
    public static final Item RATTLE=new Item(new Item.Settings().maxCount(1)) {
        @Override public TypedActionResult<ItemStack> use(World world,PlayerEntity player,Hand hand){
            if(!world.isClient && player instanceof ServerPlayerEntity p)NurseryExtras.rattle(p,hand);
            return TypedActionResult.success(player.getStackInHand(hand),world.isClient);
        }
    };
    public static void init(){
        String[] names={"pink","cyan","yellow","purple","blue","white"};
        int[] colors={0xEAA6BC,0x73C9CC,0xEFDA83,0xBAA0DA,0x87AFE0,0xF4EEE4};
        for(int i=0;i<names.length;i++)for(var kind:GarmentItem.Kind.values()){
            String id=names[i]+"_"+kind.name().toLowerCase();var item=new GarmentItem(kind,colors[i]);
            Registry.register(Registries.ITEM,SoftDiaperMod.id(id),item);CLOTHES.put(id,item);CareContent.EXTRA_ITEMS.add(item);
        }
        Registry.register(Registries.ITEM,SoftDiaperMod.id("rattle"),RATTLE);CareContent.EXTRA_ITEMS.add(RATTLE);
    }
}
