package ru.softdiaper.network;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.packet.CustomPayload;
import ru.softdiaper.SoftDiaperMod;
public record ActionPayload(String action,String target) implements CustomPayload {
    public static final Id<ActionPayload> ID=new Id<>(SoftDiaperMod.id("care_action"));
    public static final PacketCodec<RegistryByteBuf,ActionPayload> CODEC=PacketCodec.tuple(PacketCodecs.string(32),ActionPayload::action,PacketCodecs.string(36),ActionPayload::target,ActionPayload::new);
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
