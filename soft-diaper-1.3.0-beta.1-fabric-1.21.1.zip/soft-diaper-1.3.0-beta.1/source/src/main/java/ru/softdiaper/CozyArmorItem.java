package ru.softdiaper;
import net.minecraft.item.*;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.List;
public final class CozyArmorItem extends ArmorItem {
    private final String kind;
    public CozyArmorItem(RegistryEntry<ArmorMaterial> material, Type type, String kind) {
        super(material,type,new Settings().maxCount(1)); this.kind=kind;
    }
    @Override public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.softdiaper."+kind).formatted(Formatting.LIGHT_PURPLE));
        tooltip.add(Text.translatable("tooltip.softdiaper.cozy").formatted(Formatting.GRAY));
    }
}
