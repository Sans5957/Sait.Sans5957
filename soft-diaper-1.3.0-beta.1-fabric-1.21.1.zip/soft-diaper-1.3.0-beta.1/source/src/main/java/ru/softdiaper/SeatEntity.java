package ru.softdiaper;
import net.minecraft.entity.*;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.*;
import net.minecraft.world.World;

public final class SeatEntity extends Entity {
    public SeatEntity(EntityType<? extends SeatEntity> type, World world) { super(type,world); setNoGravity(true); }
    @Override protected void initDataTracker(DataTracker.Builder builder) {}
    @Override protected void readCustomDataFromNbt(NbtCompound nbt) {}
    @Override protected void writeCustomDataToNbt(NbtCompound nbt) {}
    @Override public void tick() {
        super.tick();
        if (!getWorld().isClient && (!hasPassengers() || !getWorld().getBlockState(getBlockPos()).isOf(NurseryContent.HIGH_CHAIR))) discard();
    }
    @Override protected void updatePassengerPosition(Entity passenger, PositionUpdater updater) {
        if (hasPassenger(passenger)) updater.accept(passenger,getX(),getY(),getZ());
    }
    @Override public Vec3d updatePassengerForDismount(LivingEntity passenger) {
        // Prefer a clear, supported neighboring space over trapping the rider in the tray.
        BlockPos base=getBlockPos();
        for (Direction d : Direction.Type.HORIZONTAL) {
            BlockPos candidate=base.offset(d);
            Vec3d feet=Vec3d.ofBottomCenter(candidate);
            if (getWorld().getBlockState(candidate.down()).isSideSolidFullSquare(getWorld(),candidate.down(),Direction.UP)
                && getWorld().isSpaceEmpty(passenger,passenger.getDimensions(EntityPose.STANDING).getBoxAt(feet))) return feet;
        }
        return new Vec3d(getX(),base.getY()+2.0,getZ());
    }
    @Override public boolean isCollidable() { return false; }
    @Override protected boolean canAddPassenger(Entity passenger) { return getPassengerList().isEmpty(); }
}
