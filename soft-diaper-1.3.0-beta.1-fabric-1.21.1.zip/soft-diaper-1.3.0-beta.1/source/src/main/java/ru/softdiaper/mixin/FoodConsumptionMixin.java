package ru.softdiaper.mixin;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.softdiaper.NurseryContent;

@Mixin(ItemStack.class)
public abstract class FoodConsumptionMixin {
    // Runs once when eating finishes, not when right-click is started.
    // HEAD preserves the food component even when the last item is consumed.
    @Inject(method = "finishUsing", at = @At("HEAD"))
    private void softdiaper$afterMeal(World world, LivingEntity user, CallbackInfoReturnable<ItemStack> cir) {
        if (!world.isClient && user instanceof PlayerEntity player) {
            var food = ((ItemStack)(Object)this).get(DataComponentTypes.FOOD);
            if (food != null) NurseryContent.onFoodEaten(player, food.nutrition());
        }
    }
}
