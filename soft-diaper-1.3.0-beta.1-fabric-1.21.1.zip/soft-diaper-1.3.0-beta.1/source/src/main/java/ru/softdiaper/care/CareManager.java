package ru.softdiaper.care;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.*;
import net.minecraft.block.enums.BedPart;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.*;
import net.minecraft.entity.attribute.*;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.EntityPassengersSetS2CPacket;
import net.minecraft.particle.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.*;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import ru.softdiaper.*;
import ru.softdiaper.network.CareNetworking;
import java.util.*;

/** All item transfers, permissions, proximity and timers are authoritative on the server. */
public final class CareManager {
    public record Pair(ServerPlayerEntity nanny,ServerPlayerEntity child){}
    public record Table(ServerPlayerEntity nanny,ServerPlayerEntity child,BlockPos head,ChangingSeatEntity seat){}
    public enum Kind { CHANGE, FEED }
    public static final class Action {
        public final ServerPlayerEntity nanny,child;public final Kind kind;public final int supplySlot,wipeSlot,total;
        public final ItemStack expected,oldDiaper;public int elapsed;
        Action(ServerPlayerEntity n,ServerPlayerEntity c,Kind k,int slot,int wipe,int duration){
            nanny=n;child=c;kind=k;supplySlot=slot;wipeSlot=wipe;total=duration;
            expected=n.getInventory().getStack(slot).copy();oldDiaper=c.getEquippedStack(EquipmentSlot.LEGS);
        }
    }
    private static final Map<UUID,Pair> CARRIES=new HashMap<>();
    private static final Map<UUID,Table> TABLES=new HashMap<>();
    private static final Map<UUID,Action> ACTIONS=new HashMap<>();
    private static final Map<UUID,String> NOTICES=new HashMap<>();
    private static final Identifier CARRY_SLOW=SoftDiaperMod.id("carrying_slow");
    private CareManager(){}
    public static void init(){
        ServerTickEvents.END_SERVER_TICK.register(CareManager::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler,server)->{interrupt(handler.player);CareNetworking.close(handler.player);NOTICES.remove(handler.player.getUuid());});
        ServerLifecycleEvents.SERVER_STOPPED.register(server->{CARRIES.clear();TABLES.clear();ACTIONS.clear();NOTICES.clear();CareNetworking.clear();});
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity,source,amount)->{if(entity instanceof ServerPlayerEntity p && amount>0)interrupt(p);return true;});
    }
    public static void notice(ServerPlayerEntity player,String key){NOTICES.put(player.getUuid(),key);player.sendMessage(Text.translatable("care.softdiaper."+key),true);}
    public static String lastNotice(ServerPlayerEntity p){return NOTICES.getOrDefault(p.getUuid(),"ready");}
    public static Table table(ServerPlayerEntity child){return TABLES.get(child.getUuid());}
    public static Action action(ServerPlayerEntity child){return ACTIONS.get(child.getUuid());}
    public static boolean carried(ServerPlayerEntity child){return CARRIES.containsKey(child.getUuid());}
    public static boolean canCare(ServerPlayerEntity nanny,ServerPlayerEntity child){
        RoleStore store=RoleStore.get(nanny.getServer());
        return nanny!=child && nanny.isAlive() && child.isAlive() && !nanny.isSpectator() && !child.isSpectator()
            && nanny.getServerWorld()==child.getServerWorld() && nanny.squaredDistanceTo(child)<=9.0
            && store.linked(nanny.getUuid(),child.getUuid()) && !store.paused(child.getUuid());
    }
    public static boolean require(ServerPlayerEntity n,ServerPlayerEntity c){
        boolean other=CARRIES.values().stream().anyMatch(p->p.nanny()==n&&p.child()!=c)
            ||TABLES.values().stream().anyMatch(p->p.nanny()==n&&p.child()!=c)
            ||ACTIONS.values().stream().anyMatch(a->a.nanny==n&&a.child!=c);
        if(other){notice(n,"busy");return false;}
        if(!canCare(n,c)){notice(n,"not_allowed");return false;}return true;}
    private static boolean nannyBusy(ServerPlayerEntity n){return ACTIONS.values().stream().anyMatch(a->a.nanny==n);}
    public static boolean fresh(ItemStack s){return SoftDiaperMod.isDiaper(s)&&SoftDiaperMod.wetness(s)==0&&NurseryContent.fullness(s)==0&&!s.isDamaged();}
    private static int find(ServerPlayerEntity p,java.util.function.Predicate<ItemStack> predicate){for(int i=0;i<36;i++)if(predicate.test(p.getInventory().getStack(i)))return i;return -1;}
    public static void stopChild(ServerPlayerEntity child){
        Pair carry=CARRIES.remove(child.getUuid());Table table=TABLES.remove(child.getUuid());Action action=ACTIONS.remove(child.getUuid());
        if(carry!=null){child.stopRiding();carry.nanny().networkHandler.sendPacket(new EntityPassengersSetS2CPacket(carry.nanny()));safePlace(child,carry.nanny());pose(carry.nanny(),0,0);removeCarrySlow(carry.nanny());}
        if(table!=null){child.stopRiding();table.seat().discard();safePlace(child,table.nanny());pose(table.nanny(),0,0);}
        if(action!=null)pose(action.nanny,0,0);
        pose(child,0,0);
    }
    public static void interrupt(ServerPlayerEntity player){
        NurseryExtras.cancel(player);
        Set<ServerPlayerEntity> children=new HashSet<>();
        CARRIES.values().forEach(p->{if(p.nanny()==player||p.child()==player)children.add(p.child());});
        TABLES.values().forEach(p->{if(p.nanny()==player||p.child()==player)children.add(p.child());});
        ACTIONS.values().forEach(a->{if(a.nanny==player||a.child==player)children.add(a.child);});
        children.forEach(CareManager::stopChild);pose(player,0,0);removeCarrySlow(player);
    }
    public static boolean carry(ServerPlayerEntity n,ServerPlayerEntity c){
        if(!require(n,c))return false;
        if(carried(c)){stopChild(c);notice(n,"released");return true;}
        if(nannyBusy(n)||n.hasPassengers()||n.hasVehicle()||n.isSleeping()||c.isSleeping()
            ||(c.hasVehicle()&&!(c.getVehicle() instanceof SeatEntity)&&table(c)==null)){notice(n,"busy");return false;}
        stopChild(c);if(c.hasVehicle())c.stopRiding();
        if(!c.startRiding(n,true)){notice(n,"busy");return false;}
        CARRIES.put(c.getUuid(),new Pair(n,c));updatePose(n);updatePose(c);
        n.updatePassengerPosition(c);
        // Vanilla EntityTrackerEntry broadcasts passenger changes to tracking viewers,
        // not to the vehicle player's own connection. The nanny must receive this too.
        n.networkHandler.sendPacket(new EntityPassengersSetS2CPacket(n));
        notice(n,"carrying");notice(c,"can_stop");return true;
    }
    public static BlockPos tableHead(ServerPlayerEntity p,BlockPos pos){
        BlockState s=p.getWorld().getBlockState(pos);if(!s.isOf(CareContent.CHANGING_TABLE))return null;
        return s.get(BedBlock.PART)==BedPart.HEAD?pos:pos.offset(s.get(BedBlock.FACING));
    }
    public static BlockPos nearbyTable(ServerPlayerEntity p){
        BlockPos best=null;double distance=Double.MAX_VALUE;
        for(BlockPos b:BlockPos.iterate(p.getBlockPos().add(-3,-2,-3),p.getBlockPos().add(3,2,3))){
            BlockPos h=tableHead(p,b);if(h!=null&&p.squaredDistanceTo(Vec3d.ofCenter(h))<distance){best=h.toImmutable();distance=p.squaredDistanceTo(Vec3d.ofCenter(h));}}
        return best;
    }
    public static boolean layDown(ServerPlayerEntity n,ServerPlayerEntity c,BlockPos raw){
        if(!require(n,c))return false;
        BlockPos head=raw==null?null:tableHead(n,raw);
        if(head==null||n.squaredDistanceTo(Vec3d.ofCenter(head))>16||c.squaredDistanceTo(Vec3d.ofCenter(head))>16){notice(n,"need_table");return false;}
        if(nannyBusy(n)||c.isSleeping()||(c.hasVehicle()&&!(c.getVehicle() instanceof SeatEntity)&&!carried(c)&&table(c)==null)) {notice(n,"busy");return false;}
        for(Table t:TABLES.values())if(t.child()!=c&&t.child().getWorld()==c.getWorld()&&t.head().equals(head)){notice(n,"occupied");return false;}
        stopChild(c);if(c.hasVehicle())c.stopRiding();
        Direction facing=n.getWorld().getBlockState(head).get(BedBlock.FACING);
        ChangingSeatEntity seat=new ChangingSeatEntity(CareContent.TABLE_SEAT,n.getWorld());seat.setAnchor(head);
        seat.refreshPositionAndAngles(head.getX()+.5-facing.getOffsetX()*.5,head.getY()+1.02,head.getZ()+.5-facing.getOffsetZ()*.5,facing.asRotation(),0);
        n.getServerWorld().spawnEntity(seat);
        if(!c.startRiding(seat,true)){seat.discard();return false;}
        c.setYaw(facing.asRotation());TABLES.put(c.getUuid(),new Table(n,c,head,seat));updatePose(c);
        notice(c,"on_table");notice(n,"table_ready");return true;
    }
    public static void useTable(ServerPlayerEntity p,BlockPos pos){
        RoleStore store=RoleStore.get(p.getServer());
        if(store.role(p.getUuid())==RoleStore.Role.CHILD){
            ServerPlayerEntity n=store.guardian(p.getUuid())==null?null:p.getServer().getPlayerManager().getPlayer(store.guardian(p.getUuid()));
            if(n==null){notice(p,"need_nanny");return;}layDown(n,p,pos);
        }else if(store.role(p.getUuid())==RoleStore.Role.NANNY){
            ServerPlayerEntity c=p.getServer().getPlayerManager().getPlayerList().stream().filter(x->canCare(p,x)).min(Comparator.comparingDouble(p::squaredDistanceTo)).orElse(null);
            if(c==null){notice(p,"need_child");return;}
            if(table(c)==null){layDown(p,c,pos);}else startChange(p,c);
        }else notice(p,"no_role");
    }
    public static boolean startChange(ServerPlayerEntity n,ServerPlayerEntity c){
        if(!require(n,c))return false;
        Table t=table(c);if(t==null||t.nanny()!=n){notice(n,"need_table");return false;}
        if(nannyBusy(n)||action(c)!=null){notice(n,"busy");return false;}
        ItemStack old=c.getEquippedStack(EquipmentSlot.LEGS);
        if(!old.isEmpty()&&!SoftDiaperMod.isDiaper(old)){notice(n,"remove_leggings");return false;}
        int supply=find(n,CareManager::fresh),wipes=find(n,s->s.isOf(NurseryContent.WIPES));
        if(supply<0||wipes<0){notice(n,"need_supplies");return false;}
        ACTIONS.put(c.getUuid(),new Action(n,c,Kind.CHANGE,supply,wipes,100));updatePose(n);updatePose(c);notice(n,"changing");return true;
    }
    public static boolean startFeed(ServerPlayerEntity n,ServerPlayerEntity c){
        if(!require(n,c))return false;
        if(nannyBusy(n)||action(c)!=null||table(c)!=null||c.isSleeping()){notice(n,"busy");return false;}
        var food=n.getMainHandStack().get(DataComponentTypes.FOOD);
        if(food==null){notice(n,"need_food");return false;}
        if(!c.canConsume(food.canAlwaysEat())){notice(n,"not_hungry");return false;}
        ACTIONS.put(c.getUuid(),new Action(n,c,Kind.FEED,n.getInventory().selectedSlot,-1,40));updatePose(n);updatePose(c);notice(n,"feeding");return true;
    }
    private static boolean actionValid(Action a){
        if(!canCare(a.nanny,a.child)||a.nanny.isSneaking()||a.child.isSneaking())return false;
        ItemStack supply=a.nanny.getInventory().getStack(a.supplySlot);
        if(supply.isEmpty()||!ItemStack.areItemsAndComponentsEqual(supply,a.expected))return false;
        if(a.kind==Kind.CHANGE){Table t=table(a.child);return t!=null&&t.nanny()==a.nanny&&t.seat()==a.child.getVehicle()
            &&a.child.getEquippedStack(EquipmentSlot.LEGS)==a.oldDiaper&&fresh(supply)&&a.nanny.getInventory().getStack(a.wipeSlot).isOf(NurseryContent.WIPES);}
        var food=supply.get(DataComponentTypes.FOOD);
        return a.nanny.getInventory().selectedSlot==a.supplySlot&&food!=null&&a.child.canConsume(food.canAlwaysEat());
    }
    private static void complete(Action a){
        ItemStack supply=a.nanny.getInventory().getStack(a.supplySlot);
        if(a.kind==Kind.CHANGE){
            // Atomic at completion; no naked frame, no destruction of the old item, no double transfer.
            ItemStack replacement=supply.split(1);
            a.nanny.getInventory().getStack(a.wipeSlot).decrement(1);
            a.child.equipStack(EquipmentSlot.LEGS,replacement);
            if(!a.oldDiaper.isEmpty())a.nanny.getInventory().offerOrDrop(a.oldDiaper);
            notice(a.nanny,"changed");notice(a.child,"changed");
        }else{
            ItemStack meal=supply.copyWithCount(1);Item original=meal.getItem();
            supply.decrement(1);
            ItemStack remainder=meal.finishUsing(a.child.getWorld(),a.child);
            if(!remainder.isEmpty()&&!remainder.isOf(original))a.nanny.getInventory().offerOrDrop(remainder);
            notice(a.nanny,"fed");notice(a.child,"fed");
        }
        a.nanny.getInventory().markDirty();a.child.getInventory().markDirty();
        a.nanny.currentScreenHandler.sendContentUpdates();a.child.currentScreenHandler.sendContentUpdates();
    }
    public static void tick(MinecraftServer server){
        for(Pair p:new ArrayList<>(CARRIES.values()))if(!canCare(p.nanny(),p.child())||p.child().getVehicle()!=p.nanny()||p.child().isSneaking()||p.nanny().isSneaking())stopChild(p.child());
        for(Table t:new ArrayList<>(TABLES.values()))if(!canCare(t.nanny(),t.child())||t.child().getVehicle()!=t.seat()||t.seat().isRemoved()
            ||!t.child().getWorld().getBlockState(t.head()).isOf(CareContent.CHANGING_TABLE)||t.child().isSneaking())stopChild(t.child());
        for(Action a:new ArrayList<>(ACTIONS.values())){
            if(!actionValid(a)){ACTIONS.remove(a.child.getUuid());notice(a.nanny,"cancelled");updatePose(a.nanny);updatePose(a.child);continue;}
            a.elapsed++;
            if(a.elapsed%10==0){
                if(a.kind==Kind.FEED){
                    a.nanny.getServerWorld().spawnParticles(new ItemStackParticleEffect(ParticleTypes.ITEM,a.expected),a.child.getX(),a.child.getY()+1.0,a.child.getZ(),3,.12,.1,.12,.01);
                    a.nanny.getServerWorld().playSound(null,a.child.getBlockPos(),SoundEvents.ENTITY_GENERIC_EAT,SoundCategory.PLAYERS,.4F,1.2F);
                }else if(a.elapsed%20==0){
                    a.nanny.getServerWorld().spawnParticles(ParticleTypes.END_ROD,a.child.getX(),a.child.getY()+.3,a.child.getZ(),2,.3,.1,.3,.01);
                    a.nanny.getServerWorld().playSound(null,a.child.getBlockPos(),SoundEvents.BLOCK_WOOL_PLACE,SoundCategory.PLAYERS,.4F,1.2F);
                }
            }
            if(a.elapsed>=a.total){complete(a);ACTIONS.remove(a.child.getUuid());}
            updatePose(a.nanny);updatePose(a.child);
        }
        for(Pair p:CARRIES.values()){updatePose(p.nanny());updatePose(p.child());var speed=p.nanny().getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
            if(speed!=null&&!speed.hasModifier(CARRY_SLOW))speed.addTemporaryModifier(new EntityAttributeModifier(CARRY_SLOW,-.25,EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));}
        if(server.getTicks()%10==0)CareNetworking.refresh(server);
    }
    public static void updatePose(ServerPlayerEntity p){
        int flags=0,progress=0;
        if(carried(p))flags|=CarePose.CARRIED;
        if(CARRIES.values().stream().anyMatch(x->x.nanny()==p))flags|=CarePose.CARRYING;
        if(table(p)!=null)flags|=CarePose.ON_TABLE;
        for(Action a:ACTIONS.values()){
            if(a.nanny==p){flags|=a.kind==Kind.CHANGE?CarePose.CHANGING:CarePose.FEEDING;progress=a.elapsed*100/a.total;}
            if(a.child==p){if(a.kind==Kind.FEED)flags|=CarePose.BEING_FED;progress=a.elapsed*100/a.total;}
        }
        pose(p,flags,progress);
    }
    private static void pose(ServerPlayerEntity p,int flags,int progress){if(p instanceof CarePose a){a.softdiaper$setPose(flags);a.softdiaper$setProgress(progress);}}
    private static void removeCarrySlow(ServerPlayerEntity p){var speed=p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);if(speed!=null)speed.removeModifier(CARRY_SLOW);}
    private static void safePlace(ServerPlayerEntity c,ServerPlayerEntity n){
        if(c.getWorld()!=n.getWorld())return;
        BlockPos origin=c.squaredDistanceTo(n)<=16?n.getBlockPos():c.getBlockPos();
        for(Direction d:Direction.Type.HORIZONTAL){BlockPos b=origin.offset(d);Vec3d feet=Vec3d.ofBottomCenter(b);
            if(c.getWorld().getBlockState(b.down()).isSideSolidFullSquare(c.getWorld(),b.down(),Direction.UP)
                &&c.getWorld().isSpaceEmpty(c,c.getDimensions(EntityPose.STANDING).getBoxAt(feet))){c.requestTeleport(feet.x,feet.y,feet.z);return;}}
        if(c.squaredDistanceTo(n)<=16)c.requestTeleport(n.getX(),n.getY(),n.getZ());
    }
    public static void sleepNearby(ServerPlayerEntity p){
        if(RoleStore.get(p.getServer()).role(p.getUuid())!=RoleStore.Role.CHILD){notice(p,"child_only");return;}
        if(p.hasVehicle()){notice(p,"stand_first");return;}
        for(BlockPos b:BlockPos.iterate(p.getBlockPos().add(-3,-1,-3),p.getBlockPos().add(3,1,3)))if(p.getWorld().getBlockState(b).isOf(CareContent.CHILD_CRIB)){
            p.getWorld().getBlockState(b).onUse(p.getWorld(),p,new BlockHitResult(b.toCenterPos(),Direction.UP,b,false));return;}
        notice(p,"need_crib");
    }
}
