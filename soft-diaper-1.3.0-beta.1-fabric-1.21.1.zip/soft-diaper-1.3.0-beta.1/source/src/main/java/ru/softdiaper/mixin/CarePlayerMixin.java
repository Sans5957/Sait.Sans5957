package ru.softdiaper.mixin;
import net.minecraft.entity.data.*;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.softdiaper.care.CarePose;
@Mixin(PlayerEntity.class)
public abstract class CarePlayerMixin implements CarePose, ru.softdiaper.care.WardrobeView {
    @Unique private static final TrackedData<Integer> SOFTDIAPER_POSE=DataTracker.registerData(PlayerEntity.class,TrackedDataHandlerRegistry.INTEGER);
    @Unique private static final TrackedData<Integer> SOFTDIAPER_PROGRESS=DataTracker.registerData(PlayerEntity.class,TrackedDataHandlerRegistry.INTEGER);
    @Unique private static final TrackedData<net.minecraft.item.ItemStack> SOFTDIAPER_TOP=DataTracker.registerData(PlayerEntity.class,TrackedDataHandlerRegistry.ITEM_STACK);
    @Unique private static final TrackedData<net.minecraft.item.ItemStack> SOFTDIAPER_SKIRT=DataTracker.registerData(PlayerEntity.class,TrackedDataHandlerRegistry.ITEM_STACK);
    @Override public net.minecraft.item.ItemStack softdiaper$getTop(){return ((PlayerEntity)(Object)this).getDataTracker().get(SOFTDIAPER_TOP);}
    @Override public net.minecraft.item.ItemStack softdiaper$getSkirt(){return ((PlayerEntity)(Object)this).getDataTracker().get(SOFTDIAPER_SKIRT);}
    @Override public void softdiaper$setClothes(net.minecraft.item.ItemStack top,net.minecraft.item.ItemStack skirt){
        var tracker=((PlayerEntity)(Object)this).getDataTracker();
        if(!net.minecraft.item.ItemStack.areEqual(tracker.get(SOFTDIAPER_TOP),top))tracker.set(SOFTDIAPER_TOP,top.copy());
        if(!net.minecraft.item.ItemStack.areEqual(tracker.get(SOFTDIAPER_SKIRT),skirt))tracker.set(SOFTDIAPER_SKIRT,skirt.copy());
    }
    @Inject(method="initDataTracker",at=@At("TAIL"))
    private void softdiaper$init(DataTracker.Builder builder,CallbackInfo ci) { builder.add(SOFTDIAPER_TOP,net.minecraft.item.ItemStack.EMPTY);builder.add(SOFTDIAPER_SKIRT,net.minecraft.item.ItemStack.EMPTY);builder.add(SOFTDIAPER_POSE,0);builder.add(SOFTDIAPER_PROGRESS,0); }
    @Override public int softdiaper$getPose() {return ((PlayerEntity)(Object)this).getDataTracker().get(SOFTDIAPER_POSE);}
    @Override public void softdiaper$setPose(int v) {((PlayerEntity)(Object)this).getDataTracker().set(SOFTDIAPER_POSE,v);}
    @Override public int softdiaper$getProgress() {return ((PlayerEntity)(Object)this).getDataTracker().get(SOFTDIAPER_PROGRESS);}
    @Override public void softdiaper$setProgress(int v) {((PlayerEntity)(Object)this).getDataTracker().set(SOFTDIAPER_PROGRESS,v);}
}
