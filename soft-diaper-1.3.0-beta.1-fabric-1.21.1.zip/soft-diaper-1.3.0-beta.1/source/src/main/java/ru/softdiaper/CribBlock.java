package ru.softdiaper;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.enums.BedPart;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.*;
import net.minecraft.world.*;

/** Uses vanilla two-part bed/sleep/respawn logic, rendered with static block models. */
public class CribBlock extends BedBlock {
    public static final MapCodec<BedBlock> CODEC=createCodec(CribBlock::new);
    public CribBlock(Settings settings) { super(DyeColor.LIGHT_BLUE,settings); }
    @Override public MapCodec<BedBlock> getCodec() { return CODEC; }
    @Override public BlockEntity createBlockEntity(BlockPos pos, BlockState state) { return null; }
    @Override protected BlockRenderType getRenderType(BlockState state) { return BlockRenderType.MODEL; }
    @Override protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!isBedWorking(world)) {
            if (!world.isClient) player.sendMessage(Text.translatable("message.softdiaper.crib_dimension"),true);
            return ActionResult.SUCCESS;
        }
        return super.onUse(state,world,pos,player,hit);
    }
    @Override protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        VoxelShape s=VoxelShapes.union(createCuboidShape(0,3,0,16,9,16),
            createCuboidShape(0,9,0,1,16,16), createCuboidShape(15,9,0,16,16,16));
        s=VoxelShapes.union(s,state.get(PART)==BedPart.HEAD ? createCuboidShape(0,9,0,16,16,1) : createCuboidShape(0,9,15,16,16,16));
        return ShapeUtil.rotate(s,state.get(FACING));
    }
    @Override protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        // Railings are decorative so vanilla bed wake-up and respawn have safe clearance.
        return createCuboidShape(0,0,0,16,9,16);
    }
}
