package ru.softdiaper;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.*;
public final class ShapeUtil {
    private ShapeUtil() {}
    public static VoxelShape rotate(VoxelShape input, Direction facing) {
        int turns = switch(facing) { case EAST -> 1; case SOUTH -> 2; case WEST -> 3; default -> 0; };
        VoxelShape shape=input;
        for(int i=0;i<turns;i++) {
            VoxelShape[] next={VoxelShapes.empty()};
            shape.forEachBox((x1,y1,z1,x2,y2,z2)->next[0]=VoxelShapes.union(next[0],VoxelShapes.cuboid(1-z2,y1,x1,1-z1,y2,x2)));
            shape=next[0];
        }
        return shape;
    }
}
