package ru.softdiaper;

import com.mojang.serialization.Codec;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.ComponentType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.item.*;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import java.util.List;
import java.util.Map;

public final class SoftDiaperMod implements ModInitializer {
    public static final String ID = "softdiaper";
    public static Identifier id(String path) { return Identifier.of(ID, path); }

    public static final ComponentType<Integer> WETNESS = Registry.register(
        Registries.DATA_COMPONENT_TYPE, id("wetness"),
        ComponentType.<Integer>builder().codec(Codec.intRange(0, 100)).packetCodec(PacketCodecs.VAR_INT).build());

    public static final RegistryEntry<ArmorMaterial> MATERIAL = Registry.registerReference(
        Registries.ARMOR_MATERIAL, id("cotton"), new ArmorMaterial(
            Map.of(ArmorItem.Type.HELMET, 0, ArmorItem.Type.CHESTPLATE, 0,
                   ArmorItem.Type.LEGGINGS, 1, ArmorItem.Type.BOOTS, 0, ArmorItem.Type.BODY, 0),
            10, SoundEvents.ITEM_ARMOR_EQUIP_LEATHER, () -> Ingredient.ofItems(Items.WHITE_WOOL),
            List.of(new ArmorMaterial.Layer(id("cotton"))), 0.0F, 0.0F));

    public static final Item DIAPER = Registry.register(Registries.ITEM, id("diaper"),
        new DiaperItem(MATERIAL, new Item.Settings().maxDamage(120).component(WETNESS, 0)));

    private static final Identifier SOAKED = id("soaked");

    public static boolean isDiaper(ItemStack stack) { return stack.getItem() instanceof DiaperItem; }

    public static int wetness(ItemStack stack) {
        return DiaperRules.clamp(stack.getOrDefault(WETNESS, 0));
    }

    @Override public void onInitialize() {
        NurseryContent.init();
        CareContent.init();
        PlayContent.init();
        ru.softdiaper.care.NurseryExtras.init();
        ru.softdiaper.care.CareManager.init();
        ru.softdiaper.network.CareNetworking.init();
        ru.softdiaper.care.CareCommands.init();
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> CareContent.EXTRA_ITEMS.forEach(entries::add));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> entries.add(DIAPER));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> NurseryContent.ALL_ITEMS.forEach(entries::add));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (var player : server.getPlayerManager().getPlayerList()) {
                ItemStack stack = player.getEquippedStack(EquipmentSlot.LEGS);
                boolean wearing = isDiaper(stack) && !player.isSpectator();
                NurseryContent.tick(player,stack,wearing);
                if (wearing && player.age % 100 == 0) {
                    int old = wetness(stack);
                    int next = DiaperRules.afterWeather(old, player.isTouchingWater(), player.isTouchingWaterOrRain());
                    if (next != old) {
                        stack.set(WETNESS, next);
                        if (next == 100) player.sendMessage(Text.translatable("message.softdiaper.soaked"), true);
                        if (next == 0) player.sendMessage(Text.translatable("message.softdiaper.dry"), true);
                    }
                }
                // Our own temporary modifier, not a potion effect: removing the item never
                // removes slowness from another source, and the penalty cannot persist on logout.
                var speed = player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
                if (speed != null) {
                    double penalty = wearing ? NurseryRules.speedPenalty(wetness(stack),NurseryContent.fullness(stack)) : 0;
                    var modifier = speed.getModifier(SOAKED);
                    if (modifier != null && (penalty == 0 || modifier.value() != -penalty)) speed.removeModifier(SOAKED);
                    if (penalty > 0 && !speed.hasModifier(SOAKED)) {
                        speed.addTemporaryModifier(new EntityAttributeModifier(SOAKED, -penalty,
                            EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                    }
                }
            }
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack paper = player.getStackInHand(hand);
            ItemStack diaper = player.getEquippedStack(EquipmentSlot.LEGS);
            if (!player.isSpectator() && player.isSneaking() && paper.isOf(Items.PAPER) && isDiaper(diaper)) {
                if (wetness(diaper) == 0) {
                    if (!world.isClient) player.sendMessage(Text.translatable("message.softdiaper.already_dry"), true);
                    return TypedActionResult.success(paper, world.isClient);
                }
                if (!world.isClient) {
                    diaper.set(WETNESS, DiaperRules.dryWithPaper(wetness(diaper)));
                    if (!player.getAbilities().creativeMode) paper.decrement(1);
                    player.sendMessage(Text.translatable("message.softdiaper.paper", wetness(diaper)), true);
                    world.playSound(null, player.getBlockPos(), SoundEvents.ITEM_ARMOR_EQUIP_LEATHER.value(),
                        SoundCategory.PLAYERS, 0.8F, 1.2F);
                }
                return TypedActionResult.success(paper, world.isClient);
            }
            return TypedActionResult.pass(paper);
        });

        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            ItemStack stack = entity.getEquippedStack(EquipmentSlot.LEGS);
            if (isDiaper(stack) && source.isOf(DamageTypes.FALL) && NurseryRules.canCushion(wetness(stack), NurseryContent.fullness(stack), amount)) {
                stack.damage(1, entity, EquipmentSlot.LEGS);
                entity.getWorld().playSound(null, entity.getBlockPos(), SoundEvents.BLOCK_WOOL_FALL,
                    SoundCategory.PLAYERS, 0.8F, 1.3F);
                return false;
            }
            return true;
        });
    }
}
