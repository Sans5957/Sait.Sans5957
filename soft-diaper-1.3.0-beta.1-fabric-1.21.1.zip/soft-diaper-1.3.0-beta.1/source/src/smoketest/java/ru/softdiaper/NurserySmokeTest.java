package ru.softdiaper;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.block.*;
import net.minecraft.block.enums.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.common.SyncedClientOptions;
import net.minecraft.recipe.input.CraftingRecipeInput;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import java.util.*;

/** Not included in the released mod JAR. Runs against the actual game classes. */
public final class NurserySmokeTest implements ModInitializer {
    private int checks=0;
    private void check(boolean result,String message) {
        if (!result) throw new AssertionError(message);
        checks++; System.out.println("NURSERY PASS: "+message);
    }
    @Override public void onInitialize() {
        if (!Boolean.getBoolean("softdiaper.smoke")) return;
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            try { run(server); int careChecks=new CareSmokeTest().run(server);int playChecks=new PlaySmokeTest().run(server);System.out.println("PLAY SMOKE SUCCESS: "+playChecks+" checks"); System.out.println("CARE SMOKE SUCCESS: "+careChecks+" checks"); System.out.println("NURSERY SMOKE SUCCESS: "+checks+" checks"); }
            catch (Throwable t) { System.out.println("NURSERY SMOKE FAILED"); t.printStackTrace(); }
            finally { server.stop(false); }
        });
    }
    private void run(MinecraftServer server) {
        var world=server.getOverworld();
        // Make repeated runs safe and deterministic inside this dedicated test world.
        world.getChunk(0,0);
        for (var drop : world.getEntitiesByClass(ItemEntity.class,new Box(-4,60,-4,12,72,12),e -> true)) drop.discard();
        for (int x=-2;x<=10;x++) for(int z=-2;z<=10;z++) for(int y=65;y<=68;y++)
            world.setBlockState(new BlockPos(x,y,z),Blocks.AIR.getDefaultState(),Block.NOTIFY_ALL | Block.SKIP_DROPS);
        var player=new ServerPlayerEntity(server,world,new GameProfile(UUID.randomUUID(),"NurseryTest"),SyncedClientOptions.createDefault());
        // Real ServerPlayerEntity behavior, with Fabric's no-op fake network connection.
        player.networkHandler=FakePlayer.get(world).networkHandler;
        player.changeGameMode(net.minecraft.world.GameMode.SURVIVAL);
        player.refreshPositionAndAngles(0.5,65,0.5,0,0);
        player.getHungerManager().setFoodLevel(8);
        var diaper=new ItemStack(SoftDiaperMod.DIAPER);
        player.equipStack(EquipmentSlot.LEGS,diaper);
        new ItemStack(Items.BREAD,2).finishUsing(world,player);
        check(NurseryContent.fullness(diaper)==20,"completed bread consumption invokes food mixin (+20)");
        new ItemStack(NurseryContent.LAXATIVE,2).finishUsing(world,player);
        check(player.hasStatusEffect(NurseryContent.LAXATIVE_EFFECT),"laxative applies custom effect");
        check(player.getStatusEffect(NurseryContent.LAXATIVE_EFFECT).getDuration()==1200,"effect duration is 60 seconds");
        new ItemStack(Items.BREAD,2).finishUsing(world,player);
        check(NurseryContent.fullness(diaper)==60,"laxative doubles food fullness (+40)");
        player.age=100;
        NurseryContent.tick(player,diaper,true);
        check(NurseryContent.fullness(diaper)==65,"laxative adds periodic fullness (+5)");
        new ItemStack(NurseryContent.FRESHNESS_PILL,2).finishUsing(world,player);
        check(!player.hasStatusEffect(NurseryContent.LAXATIVE_EFFECT),"freshness pill removes laxative effect");
        check(NurseryContent.fullness(diaper)==25,"freshness pill removes 40 fullness");
        diaper.set(SoftDiaperMod.WETNESS,100);
        player.setStackInHand(Hand.MAIN_HAND,new ItemStack(NurseryContent.WIPES,4));
        NurseryContent.WIPES.use(world,player,Hand.MAIN_HAND);
        check(NurseryContent.fullness(diaper)==0,"wipes clean fullness to zero");
        check(SoftDiaperMod.wetness(diaper)==75,"wipes reduce wetness by 25");
        check(player.getMainHandStack().getCount()==3,"one wipe consumed in survival");
        // Cake is a block interaction rather than ItemStack.finishUsing.
        var cake=new BlockPos(4,65,0);
        world.setBlockState(cake.down(),Blocks.STONE.getDefaultState());world.setBlockState(cake,Blocks.CAKE.getDefaultState());
        player.getHungerManager().setFoodLevel(8);
        world.getBlockState(cake).onUse(world,player,new BlockHitResult(cake.toCenterPos(),Direction.UP,cake,false));
        check(NurseryContent.fullness(diaper)==11,"cake slice invokes block-food mixin (+11)");
        // Place and rotate a real chair with its BlockItem.
        var base=new BlockPos(0,65,3);
        world.setBlockState(base.down(),Blocks.STONE.getDefaultState());
        for(Direction d:Direction.Type.HORIZONTAL)world.setBlockState(base.offset(d).down(),Blocks.STONE.getDefaultState());
        player.setYaw(90); // facing WEST -> chair faces EAST
        player.setStackInHand(Hand.MAIN_HAND,new ItemStack(NurseryContent.HIGH_CHAIR_ITEM));
        var groundHit=new BlockHitResult(Vec3d.ofBottomCenter(base),Direction.UP,base.down(),false);
        var place=((BlockItem)NurseryContent.HIGH_CHAIR_ITEM).place(new ItemPlacementContext(player,Hand.MAIN_HAND,player.getMainHandStack(),groundHit));
        check(place.isAccepted(),"chair places through BlockItem");
        check(world.getBlockState(base).isOf(NurseryContent.HIGH_CHAIR),"chair lower block exists");
        check(world.getBlockState(base.up()).isOf(NurseryContent.HIGH_CHAIR),"chair upper block exists");
        check(world.getBlockState(base).get(HighChairBlock.FACING)==Direction.EAST,"chair placement orientation is EAST");
        check(world.getBlockState(base.up()).get(HighChairBlock.FACING)==Direction.EAST,"chair upper orientation matches lower");
        world.getBlockState(base).onUse(world,player,new BlockHitResult(base.toCenterPos(),Direction.NORTH,base,false));
        check(player.getVehicle() instanceof SeatEntity,"right-click mounts the real seat entity");
        var seat=(SeatEntity)player.getVehicle();
        seat.updatePassengerPosition(player);
        check(Math.abs(player.getY()-(base.getY()+0.8))<0.01,"passenger seated at expected height");
        int before=NurseryContent.fullness(diaper);
        new ItemStack(Items.BREAD,2).finishUsing(world,player);
        check(NurseryContent.fullness(diaper)==before+20,"food can be consumed while seated");
        player.stopRiding();seat.tick();
        check(seat.isRemoved(),"empty seat entity cleans itself up");
        world.breakBlock(base.up(),true);
        check(world.getBlockState(base).isAir() && world.getBlockState(base.up()).isAir(),"breaking upper chair removes both halves");
        var drops=world.getEntitiesByClass(ItemEntity.class,new Box(base).expand(2),e->e.getStack().isOf(NurseryContent.HIGH_CHAIR_ITEM));
        check(drops.stream().mapToInt(e->e.getStack().getCount()).sum()==1,"chair drops exactly one item when upper half breaks");
        // Actual vanilla bed sleep logic, with the static crib model instead of a block entity.
        var foot=new BlockPos(6,65,6);
        for(int x=4;x<10;x++)for(int z=4;z<10;z++)world.setBlockState(new BlockPos(x,64,z),Blocks.STONE.getDefaultState());
        player.refreshPositionAndAngles(6.5,65,7.5,180,0);
        player.setStackInHand(Hand.MAIN_HAND,new ItemStack(NurseryContent.CRIB_ITEM));
        var hit=new BlockHitResult(Vec3d.ofBottomCenter(foot),Direction.UP,foot.down(),false);
        check(((BlockItem)NurseryContent.CRIB_ITEM).place(new ItemPlacementContext(player,Hand.MAIN_HAND,player.getMainHandStack(),hit)).isAccepted(),"crib places through BlockItem");
        var footState=world.getBlockState(foot);
        check(footState.isOf(NurseryContent.CRIB),"crib foot exists");
        var head=foot.offset(footState.get(BedBlock.FACING));
        check(world.getBlockState(head).get(BedBlock.PART)==BedPart.HEAD,"crib head exists in correct direction");
        world.setTimeOfDay(18000);
        world.calculateAmbientDarkness();
        var sleep=player.trySleep(head);
        check(sleep.right().isPresent(),"vanilla sleep accepts the crib: "+sleep);
        check(player.isSleeping(),"player enters sleeping pose in crib");
        check(head.equals(player.getSpawnPointPosition()),"crib sets respawn point");
        player.wakeUp(false,false);
        world.breakBlock(foot,true);
        check(world.getBlockState(foot).isAir() && world.getBlockState(head).isAir(),"breaking crib foot removes both halves");
        var cribDrops=world.getEntitiesByClass(ItemEntity.class,new Box(foot).expand(3),e->e.getStack().isOf(NurseryContent.CRIB_ITEM));
        check(cribDrops.stream().mapToInt(e->e.getStack().getCount()).sum()==1,"crib drops exactly one item");
        // Clothing slots and the small rest bonus.
        player.equipStack(EquipmentSlot.CHEST,new ItemStack(NurseryContent.PAJAMAS));
        player.equipStack(EquipmentSlot.FEET,new ItemStack(NurseryContent.SLIPPERS));
        player.equipStack(EquipmentSlot.HEAD,new ItemStack(NurseryContent.PACIFIER));
        player.setHealth(10);player.getHungerManager().setFoodLevel(10);player.setSneaking(true);
        player.setVelocity(Vec3d.ZERO);player.age=200;
        NurseryContent.tick(player,diaper,true);
        check(player.getHealth()==11,"full cozy outfit heals one HP during night rest");
        player.equipStack(EquipmentSlot.HEAD,ItemStack.EMPTY);
        NurseryContent.tick(player,diaper,true);
        check(player.getHealth()==11,"missing pacifier disables rest bonus");
        for(String id:List.of("diaper","laxative","freshness_pill","wipes","high_chair","crib","pajamas","slippers","pacifier"))
            check(server.getRecipeManager().get(SoftDiaperMod.id(id)).isPresent(),"recipe registered: "+id);
    }
}
