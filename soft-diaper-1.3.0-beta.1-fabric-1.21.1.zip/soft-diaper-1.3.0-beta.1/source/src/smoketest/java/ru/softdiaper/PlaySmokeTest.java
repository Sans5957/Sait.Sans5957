package ru.softdiaper;
import com.mojang.authlib.GameProfile;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.network.packet.c2s.common.SyncedClientOptions;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.*;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.nbt.NbtCompound;
import ru.softdiaper.care.*;
import java.util.UUID;
public final class PlaySmokeTest {
    private int checks;
    private void check(boolean ok,String name){if(!ok)throw new AssertionError(name);checks++;System.out.println("PLAY PASS: "+name);}
    private ServerPlayerEntity player(MinecraftServer s,String name){var p=new ServerPlayerEntity(s,s.getOverworld(),new GameProfile(UUID.randomUUID(),name),SyncedClientOptions.createDefault());p.networkHandler=FakePlayer.get(s.getOverworld()).networkHandler;p.refreshPositionAndAngles(20.5,65,1.5,0,0);return p;}
    private ServerPlayerEntity nanny(MinecraftServer s,ServerPlayerEntity c){var n=player(s,"WardrobeNanny");var roles=RoleStore.get(s);roles.setRole(n.getUuid(),RoleStore.Role.NANNY);roles.bind(c.getUuid(),n.getUuid());return n;}
    private int count(ServerPlayerEntity p,Item item){int count=0;for(int i=0;i<36;i++)if(p.getInventory().getStack(i).isOf(item))count+=p.getInventory().getStack(i).getCount();return count;}
    public int run(MinecraftServer s){
        var c=player(s,"WardrobeChild");var roles=RoleStore.get(s);roles.setRole(c.getUuid(),RoleStore.Role.CHILD);
        check(c.getInventory().isEmpty()&&NurseryExtras.state(c).top.isEmpty(),"assigning child role grants neither clothes nor diaper");
        ItemStack diaper=new ItemStack(SoftDiaperMod.DIAPER);diaper.set(SoftDiaperMod.WETNESS,47);diaper.set(NurseryContent.FULLNESS,63);c.equipStack(EquipmentSlot.LEGS,diaper);
        var shirt=PlayContent.CLOTHES.get("cyan_shirt");var skirt=PlayContent.CLOTHES.get("pink_skirt");var dress=PlayContent.CLOTHES.get("purple_dress");
        c.setStackInHand(Hand.MAIN_HAND,new ItemStack(shirt));check(NurseryExtras.wear(c,c,false),"child equips shirt into cosmetic top slot");
        check(c.getMainHandStack().isEmpty()&&NurseryExtras.state(c).top.isOf(shirt),"wear consumes inventory item exactly once");
        check(((WardrobeView)c).softdiaper$getTop().isOf(shirt),"tracked clothing reflects owned top");
        c.setStackInHand(Hand.MAIN_HAND,new ItemStack(skirt));check(NurseryExtras.wear(c,c,true),"skirt and shirt can be worn together");
        check(c.getEquippedStack(EquipmentSlot.LEGS)==diaper&&SoftDiaperMod.wetness(diaper)==47&&NurseryContent.fullness(diaper)==63,"cosmetics preserve equipped diaper and its state");
        c.setStackInHand(Hand.MAIN_HAND,new ItemStack(dress));check(NurseryExtras.wear(c,c,false),"dress replaces shirt");
        check(NurseryExtras.state(c).skirt.isEmpty()&&count(c,skirt)==1&&count(c,shirt)==1,"dress returns previous shirt and skirt without deletion");
        c.setStackInHand(Hand.MAIN_HAND,new ItemStack(skirt));check(!NurseryExtras.wear(c,c,true)&&c.getMainHandStack().getCount()==1,"cannot stack skirt with dress or lose rejected supply");
        NurseryExtras.remove(c,false);check(NurseryExtras.state(c).top.isEmpty()&&count(c,dress)==1,"removing dress returns the actual item");
        NurseryExtras.remove(c,false);check(count(c,dress)==1,"repeated removal does not duplicate garment");
        var outsider=player(s,"Outsider");roles.setRole(outsider.getUuid(),RoleStore.Role.NANNY);outsider.setStackInHand(Hand.MAIN_HAND,new ItemStack(dress));
        check(!NurseryExtras.request(outsider,c,"dress"),"outsider cannot propose clothing change");
        var n=nanny(s,c);n.setStackInHand(Hand.MAIN_HAND,new ItemStack(dress));n.getMainHandStack().set(DataComponentTypes.CUSTOM_NAME,Text.literal("Gift"));
        check(NurseryExtras.request(n,c,"dress"),"linked nanny can offer clothing");
        check(NurseryExtras.state(c).top.isEmpty()&&n.getMainHandStack().getCount()==1,"offer alone neither equips nor consumes clothing");
        check(NurseryExtras.accept(c),"only child acceptance applies offered garment");
        check(n.getMainHandStack().isEmpty()&&NurseryExtras.state(c).top.getName().getString().equals("Gift"),"transfer keeps custom components and consumes one giver item");
        check(!NurseryExtras.accept(c),"offer cannot be accepted twice");
        n=nanny(s,c);n.setStackInHand(Hand.MAIN_HAND,new ItemStack(NurseryContent.WIPES,3));NurseryExtras.state(c).clean=10;
        check(NurseryExtras.request(n,c,"wash"),"wash offer requires held wipe");
        NurseryExtras.self(c,"reject");check(!NurseryExtras.accept(c)&&n.getMainHandStack().getCount()==3&&NurseryExtras.state(c).clean==10,"declining wash consumes nothing");
        n=nanny(s,c);n.setStackInHand(Hand.MAIN_HAND,new ItemStack(NurseryContent.WIPES,3));NurseryExtras.request(n,c,"wash");n.setStackInHand(Hand.MAIN_HAND,new ItemStack(Items.STICK));
        check(!NurseryExtras.accept(c)&&NurseryExtras.state(c).clean==10,"hand substitution invalidates consent");
        n=nanny(s,c);n.setStackInHand(Hand.MAIN_HAND,new ItemStack(NurseryContent.WIPES,3));NurseryExtras.request(n,c,"wash");
        check(NurseryExtras.accept(c)&&n.getMainHandStack().getCount()==2&&NurseryExtras.state(c).clean==45,"accepted wash consumes one wipe and raises cleanliness");
        n=nanny(s,c);n.setStackInHand(Hand.MAIN_HAND,new ItemStack(PlayContent.RATTLE));NurseryExtras.state(c).mood=20;NurseryExtras.request(n,c,"play");
        check(NurseryExtras.accept(c)&&NurseryExtras.state(c).mood==40&&n.getMainHandStack().getCount()==1,"joint play increases mood without consuming toy");
        check(!NurseryExtras.request(n,c,"play"),"offer cooldown prevents immediate spam");
        n=nanny(s,c);n.setStackInHand(Hand.MAIN_HAND,new ItemStack(PlayContent.RATTLE));NurseryExtras.request(n,c,"play");roles.setPaused(c.getUuid(),true);
        check(!NurseryExtras.accept(c),"care pause invalidates outstanding offer");roles.setPaused(c.getUuid(),false);
        n=nanny(s,c);n.setStackInHand(Hand.MAIN_HAND,new ItemStack(PlayContent.RATTLE));NurseryExtras.request(n,c,"play");n.setPosition(30,65,1.5);
        check(!NurseryExtras.accept(c),"distance rechecked at acceptance");
        n=nanny(s,c);n.setStackInHand(Hand.MAIN_HAND,new ItemStack(PlayContent.RATTLE));NurseryExtras.request(n,c,"play");CareManager.interrupt(c);
        check(NurseryExtras.pending(c)==null,"stop action removes pending consent");
        c.setStackInHand(Hand.MAIN_HAND,new ItemStack(PlayContent.RATTLE));int mood=NurseryExtras.state(c).mood;
        check(NurseryExtras.rattle(c,Hand.MAIN_HAND)&&NurseryExtras.state(c).mood==mood+5,"child can play independently");
        check(!NurseryExtras.rattle(c,Hand.MAIN_HAND),"rattle use obeys cooldown");
        var store=WardrobeStore.get(s);var saved=store.writeNbt(new NbtCompound(),s.getRegistryManager());var loaded=WardrobeStore.read(saved,s.getRegistryManager());var state=loaded.state(c.getUuid());
        check(state.top.isOf(dress)&&state.top.getName().getString().equals("Gift"),"wardrobe NBT roundtrip retains real item and custom name");
        check(state.clean==45&&state.mood==NurseryExtras.state(c).mood,"mood and cleanliness survive save/load");
        check(PlayContent.CLOTHES.size()==18,"six colors times three garment types registered");
        for(String id:PlayContent.CLOTHES.keySet())check(s.getRecipeManager().get(SoftDiaperMod.id(id)).isPresent(),"recipe registered: "+id);
        check(s.getRecipeManager().get(SoftDiaperMod.id("rattle")).isPresent(),"rattle crafting recipe registered");
        return checks;
    }
}
