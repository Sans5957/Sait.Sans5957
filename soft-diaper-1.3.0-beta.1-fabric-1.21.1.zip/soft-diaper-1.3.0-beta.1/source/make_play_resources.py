"""Generate 1.3 wardrobe/toy assets after all earlier resources. Pillow only."""
from pathlib import Path
from PIL import Image,ImageDraw
import json,runpy
R=Path(__file__).parent
runpy.run_path(str(R/'make_care_resources.py'))
A=R/'src/main/resources/assets/softdiaper';D=R/'src/main/resources/data/softdiaper'
def js(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
colors={'pink':('#EAA6BC','Розов','Pink'),'cyan':('#73C9CC','Бирюзов','Cyan'),'yellow':('#EFDA83','Жёлт','Yellow'),'purple':('#BAA0DA','Сиренев','Purple'),'blue':('#87AFE0','Голуб','Blue'),'white':('#F4EEE4','Бел','White')}
langs={l:json.loads((A/f'lang/{l}.json').read_text()) for l in ['ru_ru','en_us']}
for color,(rgb,ru,en) in colors.items():
 for kind in ['shirt','dress','skirt']:
  name=f'{color}_{kind}';im=Image.new('RGBA',(16,16));dr=ImageDraw.Draw(im)
  if kind=='shirt':dr.polygon([(5,2),(10,2),(14,5),(12,8),(10,6),(10,13),(5,13),(5,6),(3,8),(1,5)],fill=rgb,outline='#554e68');dr.rectangle((7,2,8,3),fill='#fff5e8');dr.rectangle((7,7,8,8),fill='#fff5e8')
  elif kind=='dress':dr.polygon([(5,1),(10,1),(11,5),(9,6),(14,14),(1,14),(6,6),(4,5)],fill=rgb,outline='#554e68');dr.line((5,6,10,6),fill='#fff5e8');dr.line((3,12,12,12),fill='#fff5e8')
  else:dr.polygon([(5,3),(10,3),(14,13),(1,13)],fill=rgb,outline='#554e68');dr.line((5,5,10,5),fill='#fff5e8');dr.line((3,11,12,11),fill='#fff5e8')
  im.save(A/f'textures/item/{name}.png');js(A/f'models/item/{name}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'softdiaper:item/{name}'}})
  pattern={'shirt':['W W','WDW',' W '],'dress':['W W','WDW','WWW'],'skirt':[' D ','WWW','W W']}[kind]
  js(D/f'recipe/{name}.json',{'type':'minecraft:crafting_shaped','category':'equipment','pattern':pattern,'key':{'W':{'item':'minecraft:white_wool'},'D':{'item':f'minecraft:{color}_dye'}},'result':{'id':f'softdiaper:{name}','count':1}})
  langs['ru_ru'][f'item.softdiaper.{name}']=ru+{'shirt':'ая футболка','dress':'ое платье','skirt':'ая юбка'}[kind]
  langs['en_us'][f'item.softdiaper.{name}']=en+' '+kind.capitalize()
im=Image.new('RGBA',(64,64),(237,237,237,255));dr=ImageDraw.Draw(im)
for y in range(0,64,2):
 for x in range(y%4,64,4):dr.point((x,y),fill='#d9d9d9')
dr.rectangle((20,21,25,25),fill='white');dr.rectangle((21,20,22,20),fill='white');dr.rectangle((24,20,25,20),fill='white');dr.rectangle((22,26,24,26),fill='white')
for y in [34,37,47,54]:dr.line((0,y,63,y),fill='#ffffff')
im.save(A/'textures/entity/clothes.png')
im=Image.new('RGBA',(16,16));dr=ImageDraw.Draw(im);dr.ellipse((2,1,13,10),fill='#86d9dd',outline='#477c96');dr.ellipse((5,3,10,8),fill='#f3c1d5');dr.rectangle((7,10,8,13),fill='#f2d998');dr.ellipse((5,12,10,15),fill='#eed68e',outline='#87705c');im.save(A/'textures/item/rattle.png')
js(A/'models/item/rattle.json',{'parent':'minecraft:item/handheld','textures':{'layer0':'softdiaper:item/rattle'}})
js(D/'recipe/rattle.json',{'type':'minecraft:crafting_shaped','category':'misc','pattern':[' N ','WSW',' T '],'key':{'N':{'item':'minecraft:iron_nugget'},'W':{'item':'minecraft:white_wool'},'S':{'item':'minecraft:wheat_seeds'},'T':{'item':'minecraft:stick'}},'result':{'id':'softdiaper:rattle','count':1}})
extra={
'item.softdiaper.rattle':('Погремушка','Rattle'),
'gui.softdiaper.page0':('Уход','Care'),'gui.softdiaper.page1':('Гардероб','Wardrobe'),'gui.softdiaper.page2':('Занятия','Activities'),
'gui.softdiaper.wear_upper':('Надеть верх из руки','Wear held top'),'gui.softdiaper.wear_lower':('Надеть юбку из руки','Wear held skirt'),
'gui.softdiaper.remove_upper':('Снять верх','Remove top'),'gui.softdiaper.remove_lower':('Снять юбку','Remove skirt'),
'gui.softdiaper.dress':('Предложить одежду','Offer clothing'),'gui.softdiaper.wash':('Предложить умывание','Offer wash'),
'gui.softdiaper.play':('Предложить игру','Offer play'),'gui.softdiaper.bed':('Уложить в кроватку','Offer bedtime'),
'gui.softdiaper.accept':('Принять предложение','Accept offer'),'gui.softdiaper.reject':('Отклонить','Decline'),
'gui.softdiaper.request_food':('Попросить еду','Ask for food'),'gui.softdiaper.request_bed':('Попроситься спать','Ask for bedtime'),
'gui.softdiaper.request_play':('Попросить поиграть','Ask to play'),'gui.softdiaper.request_wash':('Попросить умыть','Ask for wash'),
'gui.softdiaper.toy':('Поиграть с погремушкой','Use held rattle'),
'gui.softdiaper.mood':('Настроение: %s%%','Mood: %s%%'),'gui.softdiaper.clean':('Чистота: %s%%','Cleanliness: %s%%'),
'gui.softdiaper.slot_top':('Верх: футболка или платье','Top: shirt or dress'),'gui.softdiaper.slot_skirt':('Юбка','Skirt'),
'gui.softdiaper.empty':('Пусто','Empty'),'gui.softdiaper.layer_hint':('Отдельные слоты: памперс остаётся надетым.','Separate slots: diaper stays equipped.'),
'gui.softdiaper.offer':('Предложение: %s','Offer: %s'),'gui.softdiaper.consent_hint':('Новые действия няни — с согласия ребёнка.','New nanny actions require child consent.'),
'gui.softdiaper.none_title':('МОЙ ГАРДЕРОБ','MY WARDROBE'),
'extra.softdiaper.dress':('переодевание','clothing change'),'extra.softdiaper.wash':('умывание','wash'),
'extra.softdiaper.play':('игра','play'),'extra.softdiaper.bed':('сон','bedtime'),
'care.softdiaper.need_garment':('Возьмите подходящую одежду в основную руку.','Hold a matching garment in your main hand.'),
'care.softdiaper.remove_dress':('Сначала снимите платье: оно занимает весь наряд.','Remove the dress before putting on a skirt.'),
'care.softdiaper.dressed':('Одежда надета. Памперс не изменён.','Clothing equipped. Diaper unchanged.'),
'care.softdiaper.wait':('Подождите несколько секунд.','Please wait a few seconds.'),
'care.softdiaper.need_wipe_hand':('Для умывания держите салфетку в основной руке.','Hold a wipe in your main hand to wash.'),
'care.softdiaper.need_rattle':('Нужна погремушка в руке; перерыв между играми 5 с.','Hold a rattle; wait 5 seconds between uses.'),
'care.softdiaper.offered':('Предложение отправлено игроку %s на 30 секунд.','Offer sent to %s for 30 seconds.'),
'care.softdiaper.offer':('%s предлагает: %s. Откройте G и примите или отклоните.','%s offers: %s. Open G to accept or decline.'),
'care.softdiaper.consent_needed':('Няня ждёт ответа. Принять или отклонить — вверху кнопок.','Your nanny is waiting. Accept or decline using the first buttons.'),
'care.softdiaper.offer_expired':('Предложение истекло или условия ухода изменились.','Offer expired or care conditions changed.'),
'care.softdiaper.washed':('Умывание: чистота +35, настроение +5.','Washed: cleanliness +35, mood +5.'),
'care.softdiaper.played':('Совместная игра: настроение +20.','Played together: mood +20.'),
'care.softdiaper.request_sent':('Просьба отправлена назначенной няне.','Request sent to your assigned nanny.'),
'care.softdiaper.request_food':('%s просит покормить.','%s asks for food.'),
'care.softdiaper.request_play':('%s просит поиграть.','%s asks to play.'),
'care.softdiaper.request_wash':('%s просит умыть.','%s asks for a wash.'),
'care.softdiaper.request_bed':('%s просится спать.','%s asks for bedtime.'),
}
for key,(ru,en) in extra.items():langs['ru_ru'][key]=ru;langs['en_us'][key]=en
for lang,d in langs.items():js(A/f'lang/{lang}.json',d)
print('Generated 18 garments, wearable fabric, rattle, 19 recipes, RU/EN UI.')
