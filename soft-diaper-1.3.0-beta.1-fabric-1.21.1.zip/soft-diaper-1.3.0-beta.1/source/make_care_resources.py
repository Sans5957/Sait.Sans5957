"""Generate the 1.2 care update. Requires Pillow; no downloaded artwork."""
from pathlib import Path
from PIL import Image,ImageDraw
import json,runpy,copy
ROOT=Path(__file__).parent
runpy.run_path(str(ROOT/'make_nursery_resources.py'))
R=ROOT/'src/main/resources';A=R/'assets/softdiaper';D=R/'data/softdiaper'
def js(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def png(p,im):p.parent.mkdir(parents=True,exist_ok=True);im.save(p)
# Eliminate the legacy flat helmet layer. Only the new head-attached 3D feature renders.
for i in (1,2):png(A/'textures/models/armor'/f'pacifier_layer_{i}.png',Image.new('RGBA',(64,32)))
im=Image.new('RGBA',(32,32),'#86d2dc');d=ImageDraw.Draw(im)
d.rectangle((0,0,15,7),fill='#a2e5e5');d.line((0,0,15,0),fill='#e0ffef');d.line((0,6,15,6),fill='#4d98b2')
d.rectangle((0,8,15,15),fill='#e8adc8');d.rectangle((0,8,15,9),fill='#f8d1e0')
d.rectangle((0,16,15,31),fill='#64b7d0');d.rectangle((0,16,15,17),fill='#b4eeee')
d.rectangle((16,16,31,31),fill='#f7f4e8');d.rectangle((16,20,31,21),fill='#8ed3d8')
png(A/'textures/entity/pacifier_3d.png',im)
# A 3D inventory/hand model as well as the dedicated worn model.
def cube(a,b,t):return {'from':list(a),'to':list(b),'faces':{f:{'texture':'#'+t,'uv':[0,0,16,16]} for f in ['north','south','east','west','up','down']}}
for name,color in [('pacifier_teal','#88d5dd'),('pacifier_pink','#ecb5ce')]:
 im=Image.new('RGBA',(16,16),color);d=ImageDraw.Draw(im);d.line((0,0,15,0),fill='#d6f3ec');png(A/'textures/item'/f'{name}.png',im)
pacifier=[cube((3,9,7),(13,12,9),'teal'),cube((7,10,5),(9,12,7),'pink'),cube((5,4,6),(6,9,7),'teal'),cube((10,4,6),(11,9,7),'teal'),cube((6,3,6),(10,4,7),'teal'),cube((6,8,6),(10,9,7),'teal')]
js(A/'models/item/pacifier.json',{'gui_light':'front','textures':{'teal':'softdiaper:item/pacifier_teal','pink':'softdiaper:item/pacifier_pink','particle':'softdiaper:item/pacifier_teal'},'elements':pacifier,'display':{'gui':{'rotation':[15,-25,0],'scale':[1.1,1.1,1.1]},'ground':{'translation':[0,3,0],'scale':[.5,.5,.5]},'fixed':{'rotation':[0,180,0],'scale':[1,1,1]},'thirdperson_righthand':{'rotation':[0,0,0],'translation':[0,2,0],'scale':[.6,.6,.6]},'firstperson_righthand':{'rotation':[0,-20,0],'translation':[0,1,0],'scale':[.8,.8,.8]}}})
colors={'white':('#f2f4ea','Белый'),'orange':('#ec963b','Оранжевый'),'magenta':('#c767c6','Пурпурный'),'light_blue':('#72c8e2','Голубой'),'yellow':('#efd16a','Жёлтый'),'lime':('#a3d569','Лаймовый'),'pink':('#e99abb','Розовый'),'gray':('#7e8797','Серый'),'light_gray':('#c7c9c9','Светло-серый'),'cyan':('#4eacb8','Бирюзовый'),'purple':('#aa85d0','Фиолетовый'),'blue':('#6a8bd1','Синий'),'brown':('#af8b71','Коричневый'),'green':('#85a374','Зелёный'),'red':('#d3767c','Красный'),'black':('#606978','Чёрный')}
ids=['softdiaper:diaper']
for color,(hexcolor,name) in colors.items():
 if color=='white':continue
 rgb=tuple(int(hexcolor[i:i+2],16) for i in (1,3,5));id=color+'_diaper';ids.append('softdiaper:'+id)
 for suffix in ['', '_damp','_soaked','_full']:
  im=Image.open(A/'textures/item'/('diaper'+suffix+'.png')).convert('RGBA');px=im.load()
  for y in range(im.height):
   for x in range(im.width):
    r,g,b,a=px[x,y]
    if a and min(r,g,b)>175:
     px[x,y]=(*(int(v*.78+max(r,g,b)*.22) for v in rgb),a)
  png(A/'textures/item'/(id+suffix+'.png'),im)
  model={'parent':'minecraft:item/generated','textures':{'layer0':'softdiaper:item/'+id+suffix}}
  if not suffix:model['overrides']=[{'predicate':{'softdiaper:wetness':.5},'model':'softdiaper:item/'+id+'_damp'},{'predicate':{'softdiaper:wetness':1},'model':'softdiaper:item/'+id+'_soaked'},{'predicate':{'softdiaper:fullness':1},'model':'softdiaper:item/'+id+'_full'}]
  js(A/'models/item'/(id+suffix+'.json'),model)
 for layer in (1,2):
  im=Image.open(A/'textures/models/armor'/f'cotton_layer_{layer}.png').convert('RGBA');px=im.load()
  for y in range(im.height):
   for x in range(im.width):
    r,g,b,a=px[x,y]
    if a and min(r,g,b)>175:px[x,y]=(*(int(v*.8+max(r,g,b)*.2) for v in rgb),a)
  png(A/'textures/models/armor'/f'cotton_{color}_layer_{layer}.png',im)
js(R/'data/softdiaper/tags/item/diapers.json',{'replace':False,'values':ids})
js(D/'recipe/diaper_dye.json',{'type':'softdiaper:diaper_dye','category':'equipment'})
# New two-part furniture models.
im=Image.new('RGBA',(16,16),'#b0ded1');d=ImageDraw.Draw(im)
for x,y in [(4,4),(12,11)]:d.line((x-1,y,x+1,y),fill='#faf0c2');d.line((x,y-1,x,y+1),fill='#faf0c2')
d.line((0,0,15,0),fill='#e6f7e6');png(A/'textures/block/care_cushion.png',im)
tex={'wood':'softdiaper:block/crib_wood','cloth':'softdiaper:block/care_cushion','particle':'softdiaper:block/crib_wood'}
parts={}
for part in ['head','foot']:
 z=0 if part=='head' else 14
 e=[cube((0,12,0),(16,14,16),'wood'),cube((1,14,0),(15,16,16),'cloth'),cube((0,3,0),(16,4,16),'wood')]
 for x in [0,14]:e.append(cube((x,0,z),(x+2,16,z+2),'wood'))
 for x in [0,15]:e.append(cube((x,14,0),(x+1,18,16),'wood'))
 e.append(cube((0,14,z),(16,18,z+1),'wood'));parts[part]=e
 js(A/'models/block'/f'changing_table_{part}.json',{'textures':tex,'elements':e})
variants={}
for facing,rot in [('north',0),('east',90),('south',180),('west',270)]:
 for part in ['head','foot']:variants[f'facing={facing},part={part}']={'model':f'softdiaper:block/changing_table_{part}','y':rot}
js(A/'blockstates/changing_table.json',{'variants':variants})
head=copy.deepcopy(parts['head'])
for e in head:e['from'][2]-=16;e['to'][2]-=16
js(A/'models/item/changing_table.json',{'textures':tex,'elements':parts['foot']+head,'display':{'gui':{'rotation':[25,225,0],'scale':[.48,.48,.48]},'ground':{'translation':[0,3,0],'scale':[.25,.25,.25]},'thirdperson_righthand':{'rotation':[75,45,0],'scale':[.3,.3,.3]},'firstperson_righthand':{'rotation':[0,225,0],'scale':[.4,.4,.4]}}})
for part in ['head','foot']:
 m=json.loads((A/'models/block'/f'crib_{part}.json').read_text());m['textures']['cloth']='softdiaper:block/care_cushion';js(A/'models/block'/f'child_crib_{part}.json',m)
m=json.loads((A/'models/item/crib.json').read_text());m['textures']['cloth']='softdiaper:block/care_cushion';js(A/'models/item/child_crib.json',m)
state=json.loads((A/'blockstates/crib.json').read_text())
for v in state['variants'].values():v['model']=v['model'].replace('block/crib_','block/child_crib_')
js(A/'blockstates/child_crib.json',state)
for name in ['changing_table','child_crib']:
 js(D/'loot_table/blocks'/f'{name}.json',{'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'softdiaper:'+name}],'conditions':[{'condition':'minecraft:block_state_property','block':'softdiaper:'+name,'properties':{'part':'head'}},{'condition':'minecraft:survives_explosion'}]}]})
js(D/'recipe/changing_table.json',{'type':'minecraft:crafting_shaped','category':'misc','pattern':['WWW','P P','P P'],'key':{'W':{'item':'minecraft:white_wool'},'P':{'tag':'minecraft:planks'}},'result':{'id':'softdiaper:changing_table','count':1}})
js(D/'recipe/child_crib.json',{'type':'minecraft:crafting_shapeless','category':'misc','ingredients':[{'item':'softdiaper:crib'},{'item':'minecraft:cyan_dye'},{'item':'minecraft:gold_nugget'}],'result':{'id':'softdiaper:child_crib','count':1}})
for name in ['changing_table','child_crib']:
 js(D/'advancement/recipes'/f'{name}.json',{'parent':'minecraft:recipes/root','criteria':{'has_wool':{'trigger':'minecraft:inventory_changed','conditions':{'items':[{'items':'minecraft:white_wool'}]}},'has_recipe':{'trigger':'minecraft:recipe_unlocked','conditions':{'recipe':'softdiaper:'+name}}},'requirements':[['has_wool','has_recipe']],'rewards':{'recipes':['softdiaper:'+name]}})
for path,values in [('block/beds',['softdiaper:child_crib']),('item/beds',['softdiaper:child_crib']),('block/mineable/axe',['softdiaper:changing_table','softdiaper:child_crib'])]:
 p=R/'data/minecraft/tags'/f'{path}.json';m=json.loads(p.read_text()) if p.exists() else {'replace':False,'values':[]};m['values']+=values;js(p,m)
ru={
 'tag.item.softdiaper.diapers':'Памперсы', 'block.softdiaper.changing_table':'Пеленальный стол', 'block.softdiaper.child_crib':'Кроватка ребёнка',
 'entity.softdiaper.changing_seat':'Место на пеленальном столе',
 'role.softdiaper.none':'Без роли','role.softdiaper.child':'Ребёнок','role.softdiaper.nanny':'Няня',
 'key.softdiaper.menu':'Меню роли','key.categories.softdiaper':'Мягкий памперс',
 'command.softdiaper.role':'Роль игрока %s: %s. Экипировка не изменена.',
 'command.softdiaper.bound':'Няня %2$s назначена ребёнку %1$s.', 'command.softdiaper.unbound':'Связь ребёнка %s с няней снята.',
 'gui.softdiaper.title':'Комната заботы','gui.softdiaper.child_title':'РЕБЁНОК  /  МОЯ КОМНАТА','gui.softdiaper.nanny_title':'НЯНЯ  /  УХОД','gui.softdiaper.none_title':'Роль не назначена',
 'gui.softdiaper.select':'Следующий →','gui.softdiaper.player':'Игрок: %s','gui.softdiaper.nanny':'Няня: %s','gui.softdiaper.offline':'не в сети','gui.softdiaper.unassigned':'не назначена',
 'gui.softdiaper.distance':'Расстояние: %s бл. (−1 — другой мир)','gui.softdiaper.no_diaper':'Памперс не надет',
 'gui.softdiaper.wet':'Влажность: %s%%','gui.softdiaper.full':'Наполнение: %s%%','gui.softdiaper.food':'Сытость: %s / 20','gui.softdiaper.progress':'Готово: %s%%',
 'gui.softdiaper.state':'Состояние: %s','gui.softdiaper.state_paused':'уход приостановлен','gui.softdiaper.state_lying':'на пеленальном столе','gui.softdiaper.state_carried':'на руках','gui.softdiaper.state_ready':'свободен',
 'gui.softdiaper.carry':'Взять / спустить с рук','gui.softdiaper.table':'На пеленальный стол','gui.softdiaper.feed':'Покормить · 2 с','gui.softdiaper.change':'Сменить памперс · 5 с',
 'gui.softdiaper.stop':'Прервать / встать','gui.softdiaper.close':'Закрыть','gui.softdiaper.call':'Позвать няню','gui.softdiaper.sleep':'Лечь в кроватку','gui.softdiaper.pause':'Пауза ухода: вкл/выкл',
 'gui.softdiaper.nanny_hint':'Еда — в основной руке. Уход — в пределах 3 блоков.', 'gui.softdiaper.child_hint':'Shift прерывает уход. Назначение роли не выдаёт вещи.',
 'care.softdiaper.ready':'Откройте меню клавишей G или командой /nursery.',
 'care.softdiaper.not_allowed':'Нужны правильные роли, назначенная няня, включённый уход и расстояние до 3 блоков.',
 'care.softdiaper.busy':'Игрок занят. Сначала завершите текущее действие.',
 'care.softdiaper.released':'Ребёнок спущен с рук.', 'care.softdiaper.carrying':'Ребёнок на руках. Shift или кнопка отмены — отпустить.',
 'care.softdiaper.can_stop':'Вы на руках. Shift или /nursery release — встать.',
 'care.softdiaper.need_table':'Нужен свободный пеленальный стол рядом с обоими игроками.',
 'care.softdiaper.occupied':'Это место уже занято.', 'care.softdiaper.on_table':'Вы на столе. Няня меняет памперс; Shift — прервать.',
 'care.softdiaper.table_ready':'Ребёнок на столе. Нужны свежий памперс и салфетка.',
 'care.softdiaper.need_nanny':'Назначенная няня должна быть в сети и рядом.', 'care.softdiaper.need_child':'Рядом нет назначенного вам ребёнка.',
 'care.softdiaper.no_role':'Администратор должен назначить роль: /nursery role <игрок> child|nanny.',
 'care.softdiaper.remove_leggings':'Сначала снимите обычные поножи ребёнка. Чужую броню стол не заменяет.',
 'care.softdiaper.need_supplies':'В инвентаре няни нужны новый сухой неповреждённый памперс и салфетка.',
 'care.softdiaper.changing':'Смена памперса: 5 секунд. Оставайтесь рядом.',
 'care.softdiaper.need_food':'Возьмите обычную еду в основную руку.', 'care.softdiaper.not_hungry':'Ребёнок сейчас не голоден.',
 'care.softdiaper.feeding':'Кормление: 2 секунды. Не меняйте еду в руке.', 'care.softdiaper.cancelled':'Уход прерван. Незавершённое действие не расходует предметы.',
 'care.softdiaper.changed':'Памперс сменён. Старый предмет возвращён няне.', 'care.softdiaper.fed':'Ребёнок поел. Одна порция еды израсходована.',
 'care.softdiaper.child_only':'Эта кроватка доступна только роли «Ребёнок».', 'care.softdiaper.stand_first':'Сначала встаньте со стула, стола или с рук.',
 'care.softdiaper.need_crib':'Рядом нет кроватки ребёнка.', 'care.softdiaper.assign_first':'Сначала назначьте роли child и nanny нужным игрокам.',
 'care.softdiaper.called':'Ребёнок %s зовёт вас.','care.softdiaper.called_ok':'Няне отправлено сообщение.',
 'tooltip.softdiaper.pacifier':'Объёмная соска у рта. Надевается в слот головы.'
}
en={
 'tag.item.softdiaper.diapers':'Diapers', 'block.softdiaper.changing_table':'Changing Table','block.softdiaper.child_crib':'Child-only Crib','entity.softdiaper.changing_seat':'Changing Table Seat',
 'role.softdiaper.none':'No role','role.softdiaper.child':'Child','role.softdiaper.nanny':'Nanny','key.softdiaper.menu':'Role menu','key.categories.softdiaper':'Soft Diaper',
 'command.softdiaper.role':'Role for %s: %s. Equipment unchanged.','command.softdiaper.bound':'Nanny %2$s assigned to child %1$s.','command.softdiaper.unbound':'Guardian link removed for %s.',
 'gui.softdiaper.title':'Care Room','gui.softdiaper.child_title':'CHILD / MY ROOM','gui.softdiaper.nanny_title':'NANNY / CARE','gui.softdiaper.none_title':'No role assigned',
 'gui.softdiaper.select':'Next child →','gui.softdiaper.player':'Player: %s','gui.softdiaper.nanny':'Nanny: %s','gui.softdiaper.offline':'offline','gui.softdiaper.unassigned':'unassigned',
 'gui.softdiaper.distance':'Distance: %s blocks (−1: other world)','gui.softdiaper.no_diaper':'No diaper equipped','gui.softdiaper.wet':'Wetness: %s%%','gui.softdiaper.full':'Fullness: %s%%','gui.softdiaper.food':'Food: %s / 20','gui.softdiaper.progress':'Progress: %s%%',
 'gui.softdiaper.state':'State: %s','gui.softdiaper.state_paused':'care paused','gui.softdiaper.state_lying':'on changing table','gui.softdiaper.state_carried':'being carried','gui.softdiaper.state_ready':'free',
 'gui.softdiaper.carry':'Pick up / put down','gui.softdiaper.table':'Onto changing table','gui.softdiaper.feed':'Feed · 2 s','gui.softdiaper.change':'Change diaper · 5 s','gui.softdiaper.stop':'Cancel / stand up','gui.softdiaper.close':'Close','gui.softdiaper.call':'Call nanny','gui.softdiaper.sleep':'Use child crib','gui.softdiaper.pause':'Toggle care pause',
 'gui.softdiaper.nanny_hint':'Hold food in main hand. Stay within 3 blocks.','gui.softdiaper.child_hint':'Sneak cancels care. Assigning a role gives no items.',
 'care.softdiaper.ready':'Open the menu with G or /nursery.','care.softdiaper.not_allowed':'Requires assigned roles, matching guardian, care enabled and distance ≤3 blocks.',
 'care.softdiaper.busy':'Player is busy. Finish the current action first.','care.softdiaper.released':'Child put down.','care.softdiaper.carrying':'Carrying the child. Sneak or cancel to put down.','care.softdiaper.can_stop':'You are being carried. Sneak or /nursery release to get down.',
 'care.softdiaper.need_table':'A free changing table must be near both players.','care.softdiaper.occupied':'This place is occupied.','care.softdiaper.on_table':'On the table. Your nanny can change the diaper. Sneak to stop.','care.softdiaper.table_ready':'Child on table. A fresh diaper and a wipe are required.',
 'care.softdiaper.need_nanny':'Your assigned nanny must be online and nearby.','care.softdiaper.need_child':'No assigned child nearby.','care.softdiaper.no_role':'Ask an administrator to use /nursery role <player> child|nanny.',
 'care.softdiaper.remove_leggings':'Remove the child’s normal leggings first. The table will not replace other armor.','care.softdiaper.need_supplies':'Nanny needs one fresh, dry, undamaged diaper and one wipe in inventory.','care.softdiaper.changing':'Changing diaper: 5 seconds. Stay close.','care.softdiaper.need_food':'Hold normal food in your main hand.','care.softdiaper.not_hungry':'The child is not hungry.','care.softdiaper.feeding':'Feeding: 2 seconds. Keep the same food selected.',
 'care.softdiaper.cancelled':'Care cancelled. Unfinished actions consume no items.','care.softdiaper.changed':'Diaper changed. Old item returned to nanny.','care.softdiaper.fed':'Child fed. One food item consumed.','care.softdiaper.child_only':'This crib requires the Child role.','care.softdiaper.stand_first':'Get off the chair, table or nanny first.','care.softdiaper.need_crib':'No child crib nearby.','care.softdiaper.assign_first':'First assign the child and nanny roles to the respective players.','care.softdiaper.called':'Child %s is calling you.','care.softdiaper.called_ok':'Message sent to your nanny.',
 'tooltip.softdiaper.pacifier':'3D pacifier attached to your mouth. Head slot.'
}
for color,(hexcolor,name) in colors.items():
 if color!='white':ru['item.softdiaper.'+color+'_diaper']=name+' памперс';en['item.softdiaper.'+color+'_diaper']=color.replace('_',' ').title()+' Diaper'
for lang,extra in [('ru_ru',ru),('en_us',en)]:
 p=A/'lang'/f'{lang}.json';d=json.loads(p.read_text());d.update(extra);js(p,d)
print('Care 1.2 resources generated: 16 colors, 3D pacifier, furniture and role UI strings.')
